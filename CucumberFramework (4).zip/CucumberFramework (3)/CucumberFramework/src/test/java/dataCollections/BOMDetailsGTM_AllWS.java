package dataCollections;

import java.util.ArrayList;

public class BOMDetailsGTM_AllWS {
	
	private static ArrayList<String> getSourceWorkstream;
	private static ArrayList<String> getSourceBOMCategory;
	private static ArrayList<String> getSourceBOMName;
	private static ArrayList<String> getSourceAssignedto;
	private static ArrayList<String> getSourceState;
	private static ArrayList<String> getSourceStatus;
	private static ArrayList<String> getSourceDueDate;
	private static ArrayList<String> getSourcePartner;
	
	public static ArrayList<String> getSourceWorkstream() {return getSourceWorkstream;}
	public static ArrayList<String> getSourceBOMCategory() {return getSourceBOMCategory;}
	public static ArrayList<String> getSourceBOMName() {return getSourceBOMName;}
	public static ArrayList<String> getSourceAssignedto() {return getSourceAssignedto;}
	public static ArrayList<String> getSourceState() {return getSourceState;}
	public static ArrayList<String> getSourceStatus() {return getSourceStatus;}
	public static ArrayList<String> getSourceDueDate() {return getSourceDueDate;}
	public static ArrayList<String> getSourcePartner() {return getSourcePartner; }
	
	public BOMDetailsGTM_AllWS(ArrayList<String> SourceWorkstream, ArrayList<String> SourceBOMCategory, 
			ArrayList<String> SourceBOMName, ArrayList<String> SourceAssignedto, ArrayList<String> SourceState,
			ArrayList<String> SourceStatus, ArrayList<String> SourceDueDate, ArrayList<String> SourcePartner) {
		BOMDetailsGTM_AllWS.getSourceWorkstream = SourceWorkstream;
		BOMDetailsGTM_AllWS.getSourceBOMCategory = SourceBOMCategory;
		BOMDetailsGTM_AllWS.getSourceBOMName = SourceBOMName;
		BOMDetailsGTM_AllWS.getSourceAssignedto = SourceAssignedto;
		BOMDetailsGTM_AllWS.getSourceState = SourceState;
		BOMDetailsGTM_AllWS.getSourceStatus = SourceStatus;
		BOMDetailsGTM_AllWS.getSourceDueDate = SourceDueDate;
		BOMDetailsGTM_AllWS.getSourcePartner = SourcePartner;
	}
}