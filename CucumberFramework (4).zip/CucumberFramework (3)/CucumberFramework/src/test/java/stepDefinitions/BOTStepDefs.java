package stepDefinitions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import com.itextpdf.text.log.SysoCounter;

import pageObjects.AssignedToMePage;
import pageObjects.DashboardPage;
import pageObjects.DetailedViewPage;
import pageObjects.LoginPage;
import pageObjects.ScoreCardPage;
import pageObjects.SummaryStatusPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

import supportLibraries.Settings;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class BOTStepDefs {

	private static Properties properties;
	private static LoginPage loginPage = new LoginPage();
	private static ReusableMethods reusableMethods=new ReusableMethods();
	private static Logger log = Logger.getLogger(BOTStepDefs.class);
	static WebDriver driver = DriverManager.getWebDriver();
	private static String workstream_overall_status,workstream_overall_status_afterupdate,allworkstream_status,allworkstream_status_afterupdate;
	private static int notrequired_count=0;
	private static HashMap<String,String> workstream_data=new HashMap<String,String>();

	public static void login() throws InterruptedException {
		properties = Settings.getInstance();
		//byte[] encodedBytes = Base64.getEncoder().encode(properties.getProperty("EncodedPassword").getBytes());
		byte[] decodedBytes = Base64.getDecoder().decode(properties.getProperty("EncodedPassword").getBytes());
		//System.out.println("Encoded password ="+encodedBytes);
		//driver.switchTo().defaultContent();
		//driver.switchTo().frame("gsft_main");
		ReusableMethods.enterData(LoginPage.userName,properties.getProperty("Username"));
		ReusableMethods.enterData(LoginPage.password,new String(decodedBytes));
		ReusableMethods.click(LoginPage.login);
	}

	public static void setImpersonateUser(String impersonateUser) throws InterruptedException {
		ReusableMethods.waitUntilElementVisible(By.xpath("//h5[contains(text(),'Good')]"));
		driver.get("https://olasandbox.service-now.com");
		ReusableMethods.click(LoginPage.userDropdown);
		ReusableMethods.clickJS(LoginPage.btnImpersonateUser);
		ReusableMethods.click(LoginPage.searchForUser);
		driver.findElement(LoginPage.userSearchInputBox).sendKeys(impersonateUser);
		//ReusableMethods.enterData(LoginPage.userSearchInputBox, impersonateUser);
		LoginPage.setImpersonateUser(impersonateUser);
		ReusableMethods.click(LoginPage.impersonateUser);
		ReusableMethods.waitForLoad();
		ReusableMethods.waitUntilElementDisabled(LoginPage.dialogBoxImpersonateUser);
		driver.get("https://olasandbox.service-now.com/ola");
		ReusableMethods.waitForLoad();
	}

	public static void selectRelease(String release) {		
		DetailedViewPage.setRelease(release);
		ReusableMethods.click(DetailedViewPage.projectRelease);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
	}

	public static void addBOM(DataTable BOMdata) throws InterruptedException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			ReusableMethods.waitForLoad();
			String workstream=bomData1.get("Workstream");
			String product=bomData1.get("Product");

			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_list, product);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

			DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.click(DetailedViewPage.workStreamButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

			ReusableMethods.click(DetailedViewPage.workStreamAddBom);
			ReusableMethods.enterData(DetailedViewPage.BOM_short_desc,bomData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.BOM_desc,bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.BOM_state,bomData1.get("State"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.BOM_category,bomData1.get("Category"));
			ReusableMethods.enterData(DetailedViewPage.BOM_due_date,bomData1.get("DueDate"));
			ReusableMethods.click(DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			//ReusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			//ReusableMethods.waitForLoad();
			//String message=driver.findElement(DetailedViewPage.added_message).getText();
			//ReusableMethods.softAssertverification(message,"Custom BOM Added.");
			//ReusableMethods.click(DetailedViewPage.close_view_edit_BOM_message);		
		}
	}
	public static void editBOM(String workstream, DataTable BOMdata) throws InterruptedException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);
			ReusableMethods.waitForLoad();
			workstream_overall_status=workstreamoverallstatus(workstream);
			allworkstream_status=driver.findElement(DetailedViewPage.all_workstream).getText();
			String BOM=bomData1.get("BOM");
			try {
				if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
					int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[3]//dir-pagination-controls/ul/li/a")).size();
					for(int j=2;j<=page_count-1;j++ ) {
						By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
						ReusableMethods.click(page);
						DetailedViewPage.setBOM(BOM);
						try{
							if (driver.findElement(By.xpath(DetailedViewPage.addedBomOptionsButton)).isDisplayed()) {
								ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
								ReusableMethods.click(DetailedViewPage.view_editBom);
								break;
							}
						}catch (Exception e) {
							System.out.println("Moving to next page to find the element");
						}
					}
				}
			}catch(Exception e) {
				System.out.println("Only one page is there!!");
				DetailedViewPage.setBOM(BOM);
				ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
				ReusableMethods.click(DetailedViewPage.view_editBom);
			}

			ReusableMethods.enterData(DetailedViewPage.BOM_short_desc,bomData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.BOM_desc,bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.BOM_state,bomData1.get("State"));
			if(bomData1.get("State").equals("Not Required")){ 
				notrequired_count+=1;	
			}
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.BOM_category,bomData1.get("Category"));
			ReusableMethods.enterData(DetailedViewPage.BOM_due_date,bomData1.get("DueDate"));
			if(!bomData1.get("AddDocumentName").equals("")) {
				ReusableMethods.click(DetailedViewPage.add_document_to_BOM);
				ReusableMethods.enterData(DetailedViewPage.document_name_BOM,bomData1.get("AddDocumentName"));
				ReusableMethods.enterData(DetailedViewPage.document_link_BOM,bomData1.get("AddDocumentLinks"));
				ReusableMethods.click(DetailedViewPage.add);
			}
			if(!bomData1.get("RemoveDocumentName").equals("")) {
				DetailedViewPage.set_BOMdocument(bomData1.get("RemoveDocumentName"));
				ReusableMethods.click(DetailedViewPage.remove_BOM_document_name);
				ReusableMethods.waitUntilElementVisible(DetailedViewPage.remove_doc_confirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(DetailedViewPage.remove_doc_confirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the link");
				ReusableMethods.click(DetailedViewPage.yes);
			}
			/*if(!bomData1.get("RemoveDependency").equals("")) {
				AppEngine_DetailedViewPage.set_dependency(bomData1.get("RemoveDependency"));
				ReusableMethods.click(AppEngine_DetailedViewPage.remove_dependency_name);
				ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.remove_dependency_confirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(AppEngine_DetailedViewPage.remove_dependency_confirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the dependency?");
				ReusableMethods.click(AppEngine_DetailedViewPage.yes);
			}*/

			ReusableMethods.click(DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();
			String message=driver.findElement(DetailedViewPage.added_message).getText();
			ReusableMethods.softAssertverification(message,"BOM Updated!");
			ReusableMethods.click(DetailedViewPage.close_view_edit_BOM_message);
		}
		workstream_overall_status_afterupdate=workstreamoverallstatus(workstream);
		allworkstream_status_afterupdate=driver.findElement(DetailedViewPage.all_workstream).getText();
		putWorkstreamData("Workstream Overall Status", workstream_overall_status);
		putWorkstreamData("Workstream Overall Status After Update", workstream_overall_status_afterupdate);
		putWorkstreamData("Workstream Not Required Update Count", String.valueOf(notrequired_count));
		putWorkstreamData("AllWorkstream Status", allworkstream_status);
		putWorkstreamData("AllWorkstream Status After Update", allworkstream_status_afterupdate);

	}

	public static void cloneBOM(String workstream, DataTable BOMdata) throws InterruptedException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);
			ReusableMethods.waitForLoad();
			String BOM=bomData1.get("BOM");
			DetailedViewPage.setBOM(BOM);
			ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);

			//HashMap<String, String> edit_bom_data=getedit_BOMdata(BOM);
			//HashMap<String, String> clone_bom_data= getclone_BOMdata(BOM);

			//if(edit_bom_data.equals(clone_bom_data)) {
			ReusableMethods.click(DetailedViewPage.copy_cloneBom);
			String clone_BOM_name=driver.findElement(DetailedViewPage.clone_BOM_name).getText();
			if(clone_BOM_name.contains("Copy of") && !clone_BOM_name.isEmpty()) {
				System.out.println("Clone BOM name contains 'Copy of'");
			}else {
				System.out.println("Clone BOM name does NOT contains 'Copy of'");
			}
			ReusableMethods.click(DetailedViewPage.cloneBOM_next);
			ReusableMethods.enterData(DetailedViewPage.clone_BOM_short_desc,bomData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.clone_BOM_desc,bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.BOM_state,bomData1.get("State"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.BOM_category,bomData1.get("Category"));
			ReusableMethods.enterData(DetailedViewPage.BOM_due_date,bomData1.get("DueDate"));
			if(!bomData1.get("AddDocumentName").equals("")) {
				ReusableMethods.click(DetailedViewPage.add_document_to_BOM);
				ReusableMethods.enterData(DetailedViewPage.document_name_BOM,bomData1.get("AddDocumentName"));
				ReusableMethods.enterData(DetailedViewPage.document_link_BOM,bomData1.get("AddDocumentLinks"));
				ReusableMethods.click(DetailedViewPage.add);
			}
			if(!bomData1.get("RemoveDocumentName").equals("")) {
				DetailedViewPage.set_BOMdocument(bomData1.get("RemoveDocumentName"));
				ReusableMethods.click(DetailedViewPage.remove_BOM_document_name);
				ReusableMethods.waitUntilElementVisible(DetailedViewPage.remove_doc_confirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(DetailedViewPage.remove_doc_confirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the link");
				ReusableMethods.click(DetailedViewPage.yes);
			}
			if(!bomData1.get("RemoveDependency").equals("")) {
				DetailedViewPage.set_dependency(bomData1.get("RemoveDependency"));
				ReusableMethods.click(DetailedViewPage.remove_dependency_name);
				ReusableMethods.waitUntilElementVisible(DetailedViewPage.remove_dependency_confirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(DetailedViewPage.remove_dependency_confirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the dependency?");
				ReusableMethods.click(DetailedViewPage.yes);
			}
			ReusableMethods.click(DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();
			String message=driver.findElement(DetailedViewPage.added_message).getText();
			ReusableMethods.softAssertverification(message,"BOM Updated!");
			ReusableMethods.click(DetailedViewPage.close_view_edit_BOM_message);
			//}
		}
	}

	private static HashMap<String, String> getedit_BOMdata(String BOM) {
		HashMap<String, String> bomdata=new HashMap<String, String>();
		DetailedViewPage.setBOM(BOM);
		ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
		ReusableMethods.click(DetailedViewPage.view_editBom);
		bomdata.put("ShortDescription",ReusableMethods.getText(DetailedViewPage.BOM_short_desc));
		bomdata.put("Description",ReusableMethods.getText(DetailedViewPage.BOM_desc));
		bomdata.put("State",ReusableMethods.getText(DetailedViewPage.BOM_state));
		bomdata.put("Category",ReusableMethods.getText(DetailedViewPage.BOM_category));
		bomdata.put("DueDate",ReusableMethods.getText(DetailedViewPage.BOM_due_date));

		//add cancel button click
		return bomdata;
	}
	private static HashMap<String, String> getclone_BOMdata(String BOM) {
		HashMap<String, String> bomdata=new HashMap<String, String>();
		DetailedViewPage.setBOM(BOM);
		ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
		ReusableMethods.click(DetailedViewPage.view_editBom);
		bomdata.put("ShortDescription",ReusableMethods.getText(DetailedViewPage.clone_BOM_short_desc));
		bomdata.put("Description",ReusableMethods.getText(DetailedViewPage.clone_BOM_desc));
		bomdata.put("State",ReusableMethods.getText(DetailedViewPage.BOM_state));
		bomdata.put("Category",ReusableMethods.getText(DetailedViewPage.BOM_category));
		bomdata.put("DueDate",ReusableMethods.getText(DetailedViewPage.BOM_due_date));

		//add cancel button click
		return bomdata;
	}

	public static void putWorkstreamData(String key, String value){
		workstream_data.put(key,value);
	}
	public static String getWorkstreamData(String key){
		return workstream_data.get(key);
	}
	public static HashMap<String,String> getWorkstreamData(){
		return workstream_data;
	}

	public static void addrisk_to_existing_BOM(String BOM, DataTable Riskdata) {
		List<Map<String, String>> riskData =Riskdata.asMaps(String.class, String.class);
		int size = riskData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> riskData1 = riskData.get(anchor);
			try {
				if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
					int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
					for(int j=2;j<=page_count-1;j++ ) {
						By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
						ReusableMethods.click(page);
						ReusableMethods.waitForLoad();
						DetailedViewPage.setBOM(BOM);
						try{
							if (driver.findElement(By.xpath(DetailedViewPage.addedBomOptionsButton)).isDisplayed()) {
								ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
								ReusableMethods.click(DetailedViewPage.addRiskToBOM);
								break;
							}
						}catch (Exception e) {
							if(j==page_count-1) {
								System.out.println("BOM is not present in the UI");
							}else {
								System.out.println("Moving to next page to find the element");
							}
						}
					}
					ReusableMethods.enterData(DetailedViewPage.BOM_short_desc,riskData1.get("ShortDescription"));
					ReusableMethods.enterData(DetailedViewPage.BOM_desc,riskData1.get("Description"));
					ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_impact,riskData1.get("Impact"));
					ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_status,riskData1.get("RiskStatus"));
					ReusableMethods.enterData(DetailedViewPage.BOM_due_date,riskData1.get("DueDate"));
					ReusableMethods.click(DetailedViewPage.add_button);
					//ReusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
					ReusableMethods.waitForLoad();
					//String message=driver.findElement(DetailedViewPage.added_message).getText();
					//ReusableMethods.softAssertverification(message," Risk Submitted! ");
					//ReusableMethods.click(DetailedViewPage.close_view_edit_BOM_message); 
				}
			}catch(Exception e1) {
				System.out.println("Only one page is there!!");
				try{
					if (driver.findElement(By.xpath(DetailedViewPage.addedBomOptionsButton)).isDisplayed()) {
						ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
						ReusableMethods.click(DetailedViewPage.addRiskToBOM);
						ReusableMethods.enterData(DetailedViewPage.BOM_short_desc,riskData1.get("ShortDescription"));
						ReusableMethods.enterData(DetailedViewPage.BOM_desc,riskData1.get("Description"));
						ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_impact,riskData1.get("Impact"));
						ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_status,riskData1.get("RiskStatus"));
						ReusableMethods.enterData(DetailedViewPage.BOM_due_date,riskData1.get("DueDate"));
						ReusableMethods.click(DetailedViewPage.add_button);
						//ReusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
						ReusableMethods.waitForLoad();
					}
				}catch (Exception e) {	
					System.out.println("BOM is not present in the UI");
				}			
			}
		}
	}

	public static void editrisk_to_existing_BOM(String workstream,DataTable Riskdata) throws InterruptedException {
		List<Map<String, String>> riskData =Riskdata.asMaps(String.class, String.class);
		int size = riskData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> riskData1 = riskData.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);
			try {
				if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[3]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
					int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[3]/div/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
					for(int j=2;j<=page_count-1;j++ ) {
						By page=By.xpath("(//*[@id='jsListView']/div[3]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
						ReusableMethods.click(page);
						DetailedViewPage.setBOM_Risk(riskData1.get("BOMname"), riskData1.get("Riskname"));
						try{
							if (driver.findElement(By.xpath(DetailedViewPage.view_editRiskOptionsButton)).isDisplayed()) {
								ReusableMethods.click(DetailedViewPage.view_editRiskOptionsButton);
								ReusableMethods.click(DetailedViewPage.view_editRisk);
								break;
							}
						}catch (Exception e) {
							System.out.println("Moving to next page to find the element");
						}
					}

				}
			}catch(Exception e) {
				System.out.println("Only one page is there!!");
				DetailedViewPage.setBOM_Risk(riskData1.get("BOMname"), riskData1.get("Riskname"));
				ReusableMethods.click(DetailedViewPage.view_editRiskOptionsButton);
				ReusableMethods.click(DetailedViewPage.view_editRisk);
				ReusableMethods.enterData(DetailedViewPage.editrisk_BOM_shortdescription,riskData1.get("ShortDescription"));
				ReusableMethods.enterData(DetailedViewPage.editrisk_BOM_description,riskData1.get("Description"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.editrisk_BOM_impactstatus,riskData1.get("Impact"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_status,riskData1.get("RiskStatus"));
				ReusableMethods.enterData(DetailedViewPage.BOM_due_date,riskData1.get("DueDate"));
				ReusableMethods.click(DetailedViewPage.add_button);
				ReusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
				ReusableMethods.waitForLoad();
				String message=driver.findElement(DetailedViewPage.added_message).getText();
				ReusableMethods.softAssertverification(message," Risk Updated! ");
				ReusableMethods.click(DetailedViewPage.close_view_edit_BOM_message); 
			}
		}
	}

	public static void adddependency_to_existing_BOM(String BOM, DataTable Dependencydata) throws InterruptedException {
		List<Map<String, String>> dependencydata =Dependencydata.asMaps(String.class, String.class);
		int size = dependencydata.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> dependencydata1 = dependencydata.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setBOM(BOM);
			ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
			ReusableMethods.click(DetailedViewPage.addDependencyToBOM);
			ReusableMethods.click(DetailedViewPage.dependent_BOM_prod_family_dropdown);
			ReusableMethods.enterData_without_TAB(DetailedViewPage.dependent_BOM_prod_family_input,dependencydata1.get("DependentBOMProductFamily"));
			DetailedViewPage.setDependent_BOM_Value(dependencydata1.get("DependentBOMProductFamily"));
			ReusableMethods.click(DetailedViewPage.dependent_BOM_value);
			ReusableMethods.click(DetailedViewPage.dependent_BOM_workstream_dropdown);
			ReusableMethods.enterData_without_TAB(DetailedViewPage.dependent_BOM_workstream_input,dependencydata1.get("DependentBOMWorkstream"));
			DetailedViewPage.setDependent_BOM_Value(dependencydata1.get("DependentBOMWorkstream"));
			ReusableMethods.click(DetailedViewPage.dependent_BOM_value);
			ReusableMethods.click(DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

			/*ReusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();
			String message=driver.findElement(DetailedViewPage.added_message).getText();
			ReusableMethods.softAssertverification(message,"Dependency added.");
			ReusableMethods.click(DetailedViewPage.close_view_edit_BOM_message); 
			 */
		}		
	}

	public static String workstreamoverallstatus(String workstream) {	
		DetailedViewPage.setWorkstream(workstream);
		workstream_overall_status=driver.findElement(By.xpath(DetailedViewPage.workStream_overall_status)).getText();
		return workstream_overall_status;
	}

	public static void add_document(DataTable Documentdata) throws InterruptedException {

		ReusableMethods.click(DashboardPage.dashboard);
		List<Map<String, String>> documentdata =Documentdata.asMaps(String.class, String.class);
		int size = documentdata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = documentdata.get(anchor);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.click(DetailedViewPage.add_document);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.enterData(DetailedViewPage.document_name,documentdata1.get("DocumentName"));
			ReusableMethods.enterData(DetailedViewPage.document_link,documentdata1.get("DocumentLinks"));
			ReusableMethods.click(DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			/*ReusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			ReusableMethods.waitUntilElementEnabled(DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();		
			String message=driver.findElement(DetailedViewPage.added_message).getText();
			ReusableMethods.softAssertverification(message,"The Document Link has been added.");
			ReusableMethods.click(DetailedViewPage.close_add_document_message); */
		}
	}

	public static void remove_document(DataTable Documentdata) throws InterruptedException {
		List<Map<String, String>> documentdata =Documentdata.asMaps(String.class, String.class);
		int size = documentdata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = documentdata.get(anchor);
			DetailedViewPage.set_document(documentdata1.get("DocumentName"));
			ReusableMethods.click(DetailedViewPage.remove_document_name);
			ReusableMethods.waitUntilElementVisible(DetailedViewPage.remove_doc_confirmation);
			ReusableMethods.waitForLoad();				
			String message=driver.findElement(DetailedViewPage.remove_doc_confirmation).getText();
			ReusableMethods.softAssertverification(message,"Are you sure you want to remove the link");
			ReusableMethods.click(DetailedViewPage.yes);
		}
	}
	public static void columnname_and_order_verification_for_a_workstream(DataTable Workstreams) {
		List<Map<String, String>> workstream =Workstreams.asMaps(String.class, String.class);
		int size = workstream.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = workstream.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(documentdata1.get("Workstreams"));
			ReusableMethods.click(DetailedViewPage.workStream);

			//BOM table validation
			List<String> expected=new ArrayList<String>();
			expected.add("BOM Category");
			expected.add("BOM Name");
			expected.add("Assigned to");
			expected.add("State");
			expected.add("Status");
			expected.add("Due Date");
			expected.add("Partner");
			List<String> actual=new ArrayList<String>();
			int n=driver.findElements(By.xpath("//thead//th")).size();
			for(int i=6;i<=12;i++) {
				String value=driver.findElement(By.xpath("(//thead//th)["+i+"]")).getText();
				value.trim();
				actual.add(value);
			}
			boolean result=expected.equals(actual);
			ReusableMethods.softAssertverification(result, true);

			//Risk table validation
			List<String> expected1=new ArrayList<String>();
			expected1.add("Applicable To");
			expected1.add("Risk Name");
			expected1.add("Assigned to");
			expected1.add("Status");
			expected1.add("Impact");
			expected1.add("Initiate Date");
			expected1.add("Due Date");
			List<String> actual1=new ArrayList<String>();
			for(int j=22;j<=28;j++) {
				String value=driver.findElement(By.xpath("(//thead//th)["+j+"]")).getText();
				value.trim();
				actual1.add(value);
			}
			boolean result1=expected1.equals(actual1);
			ReusableMethods.softAssertverification(result1, true);
		}
		DetailedViewPage.setWorkstream("//h5[contains(text(),'All Workstreams')]");
		ReusableMethods.click(DetailedViewPage.workStream);
	}

	public static void options_verification_for_workstreams(DataTable Workstreams) {
		List<Map<String, String>> workstream =Workstreams.asMaps(String.class, String.class);
		int size = workstream.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = workstream.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(documentdata1.get("Workstreams"));
			ReusableMethods.click(DetailedViewPage.workStream);
			ReusableMethods.click(DetailedViewPage.workStreamButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			String expected,actual;
			expected=driver.findElement(By.xpath(DetailedViewPage.viewdoc)).getText();
			if(documentdata1.get("Workstreams").equals("Product Ready")) {
				actual="View Scope Doc";
			}else {
				actual="View Plan Doc";
			}
			boolean result=expected.equals(actual);
			ReusableMethods.softAssertverification(result, true);
		}
	}

	public static void options_verification_for_workstreams_in_functional_lead(String Workstream, DataTable Sections) {
		List<Map<String, String>> sections =Sections.asMaps(String.class, String.class);
		int size = sections.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> sectiondata = sections.get(anchor);
			ReusableMethods.waitForLoad();		
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, Workstream);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			DetailedViewPage.setWorkstream(sectiondata.get("Options"));
			ReusableMethods.click(DetailedViewPage.workStream);
			ReusableMethods.click(DetailedViewPage.workStreamButton);
			//ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			String expected;
			boolean result = false;
			int n=driver.findElements(By.xpath(DetailedViewPage.add_delete_doc)).size();
			for(int i=1;i<=n;i++) {
				String expected_xpath="("+DetailedViewPage.add_delete_doc+")["+i+"]";
				expected=driver.findElement(By.xpath(expected_xpath)).getText();
				if(Workstream.equals("Product Ready")) {
					if(expected.equals("Add/Delete Scope Doc") || expected.equals("Add Scope Doc"))  {
						result=true;
					}else {
						result=false;
					}
				}
				else if(!Workstream.equals("Product Ready")) {
					if(expected.equals("Add/Delete Scope Doc") || expected.equals("Add Scope Doc"))  {
						result=false;
					}else {
						result=true;
					}
				}			
			}
			ReusableMethods.softAssertverification(result, true);
		}
	}

	public static void RYG_rule1(String bOM, String workstream) throws ParseException {
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream(workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitForLoad();
		try {
			if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
				int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
				for(int j=2;j<=page_count-1;j++ ) {
					By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
					ReusableMethods.click(page);
					DetailedViewPage.setBOM(bOM);
					try{
						if (driver.findElement(By.xpath(DetailedViewPage.addedBomOptionsButton)).isDisplayed()) {
							ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
							ReusableMethods.click(DetailedViewPage.view_editBom);
							break;
						}
					}catch (Exception e) {
						if(j==page_count-1) {
							System.out.println("Mentioned BOM is not present in UI");
						}
						else {
							System.out.println("Moving to next page to find the element");						
						}
					}
				}
			}
		}catch(Exception e) {
			System.out.println("Only one page is there!!");
			DetailedViewPage.setBOM(bOM);
			ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
			ReusableMethods.click(DetailedViewPage.view_editBom);
		}
		String due_dt,state;
		due_dt=ReusableMethods.getText(DetailedViewPage.BOM_due_date);
		state=ReusableMethods.getText(DetailedViewPage.BOM_state);

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
		Date firstDate = sdf.parse(due_dt);
		Date secondDate = new Date();

		long diffInMillies = Math.abs(secondDate.getTime() - firstDate.getTime());
		long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

		ReusableMethods.softAssertverification(6, diff);

		if(!state.equals("Complete") && (diff>0)) {
			String color="Red";
		}
	}

	public static void RYG_risk_rules(String status,String bOM, String workstream) {
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream(workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitForLoad();
		String status_value = null;
		try {
			if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
				int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
				for(int j=2;j<=page_count-1;j++ ) {
					By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
					ReusableMethods.click(page);
					try{
						if (driver.findElement(By.xpath("//tbody//td[6 and @title='"+bOM+"']")).isDisplayed()) {
							int n=driver.findElements(By.xpath("//tbody//td[9]")).size();		
							for(int i=1;i<n;i++) {
								String actual_bom=driver.findElement(By.xpath("//tbody//td[6]")).getText().trim();
								if(actual_bom.equals(bOM)) {
									status_value=driver.findElement(By.xpath("(//tbody//td[9])["+i+"]")).getText();
									break;
								}	
							}
						}
						break;
					}catch (Exception e) {
						if(j==page_count-1) {
							System.out.println("Mentioned BOM is not present in UI");
						}
						else {
							System.out.println("Moving to next page to find the element");						
						}
					}
				}
			}
		}catch(Exception e) {
			System.out.println("Only one page is there!!");
			try{
				if (driver.findElement(By.xpath("//tbody//td[6 and @title='"+bOM+"']")).isDisplayed()) {
					int n=driver.findElements(By.xpath("//tbody//td[9]")).size();		
					for(int i=1;i<n;i++) {
						String actual_bom=driver.findElement(By.xpath("//tbody//td[6]")).getText().trim();
						if(actual_bom.equals(bOM)) {
							status_value=driver.findElement(By.xpath("(//tbody//td[9])["+i+"]")).getText();
							break;
						}	
					}
				}
			}catch (Exception e1) {
				System.out.println("Mentioned BOM is not present in UI");						
			}
		}
		ReusableMethods.softAssertverification(status, status_value);	
	}

	public static void addrisk_to_a_workstream(String workstream, DataTable Riskdata) throws InterruptedException {
		List<Map<String, String>> riskData =Riskdata.asMaps(String.class, String.class);
		int size = riskData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> riskData1 = riskData.get(anchor);

			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);	
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.click(DetailedViewPage.workStreamButton);
			ReusableMethods.waitForLoad();
			ReusableMethods.click(DetailedViewPage.workStreamAddRisk);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

			ReusableMethods.enterData(DetailedViewPage.BOM_short_desc,riskData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.BOM_desc,riskData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_impact,riskData1.get("Impact"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_status,riskData1.get("RiskStatus"));
			ReusableMethods.enterData(DetailedViewPage.mitigation_plan,riskData1.get("MitigationPlan"));
			ReusableMethods.enterData(DetailedViewPage.BOM_due_date,riskData1.get("DueDate"));
			ReusableMethods.click(DetailedViewPage.add_button);
			//ReusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();
			//String message=driver.findElement(DetailedViewPage.added_message).getText();
			//ReusableMethods.softAssertverification(message," Risk Submitted! ");
			//ReusableMethods.click(DetailedViewPage.close_view_edit_BOM_message);

		}
	}

	public static HashMap<String, String> workstream_bom_status_data(String workstream) {
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream(workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

		HashMap<String,String> input_data = new HashMap<String,String>();
		try {
			if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
				int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
				for(int j=2;j<=page_count-1;j++ ) {
					By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
					ReusableMethods.click(page);
					int n=driver.findElements(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])")).size();		
					for(int i=1;i<=n;i++) {
						String bom_name=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])["+i+"]")).getText().trim();
						String status=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[9])["+i+"]")).getText().trim();
						String state=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[8])["+i+"]")).getText().trim();

						input_data.put(bom_name, status + "-" + state);
					}
				}
			}					
		}catch (Exception e) {
			System.out.println("Only one page is there!!");				
			int n=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6]")).size();		
			for(int i=1;i<=n;i++) {
				String bom_name=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])["+i+"]")).getText().trim();
				String status=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[9])["+i+"]")).getText().trim();
				String state=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[8])["+i+"]")).getText().trim();

				input_data.put(bom_name, status + "-" + state);				
			}
		}
		return input_data;	
	}

	public static void addBOM_FL(DataTable BOMdata) throws InterruptedException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			String Product=bomData1.get("Product");
			String workstream=bomData1.get("Workstream");
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_list, workstream);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

			DetailedViewPage.setProduct(Product);
			ReusableMethods.click(DetailedViewPage.product);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.click(DetailedViewPage.productButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.click(DetailedViewPage.productAddBom);
			ReusableMethods.enterData(DetailedViewPage.BOM_short_desc,bomData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.BOM_desc,bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.BOM_state,bomData1.get("State"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.BOM_category,bomData1.get("Category"));
			ReusableMethods.enterData(DetailedViewPage.BOM_due_date,bomData1.get("DueDate"));
			ReusableMethods.click(DetailedViewPage.add_button);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			//ReusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			//ReusableMethods.waitForLoad();
			//String message=driver.findElement(DetailedViewPage.added_message).getText();
			//ReusableMethods.softAssertverification(message,"Custom BOM Added.");
			//ReusableMethods.click(DetailedViewPage.close_view_edit_BOM_message);		
		}
	}

	public static void one_option_verification_for_BOM(String bOM, DataTable Options) {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = options.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setBOM(bOM);
			int option_size=driver.findElements(By.xpath(DetailedViewPage.total_BOM_options)).size();
			if(option_size==1) {
				ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
				try {
					if(driver.findElement(By.xpath(DetailedViewPage.view_Bom)).isDisplayed()) {
						System.out.println("View BOM option is only available which is expected");
						ReusableMethods.click(DetailedViewPage.view_Bom);
					}
				}catch(Exception e) {
					System.out.println("View BOM option is Not available which is NOT expected");
				}
			}else {
				System.out.println("More than 1 option is available which is NOT expected");
			}
		}
	}

	public static void one_option_verification_for_Risk(String risk,String BOM, DataTable Options) {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = options.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setBOM_Risk(BOM,risk);
			int option_size=driver.findElements(By.xpath(DetailedViewPage.total_risk_options)).size();
			if(option_size==1) {
				ReusableMethods.click(DetailedViewPage.view_editRiskOptionsButton);
				try {
					if(driver.findElement(By.xpath(DetailedViewPage.view_risk)).isDisplayed()) {
						System.out.println("View Risk option is only available which is expected");
						ReusableMethods.click(DetailedViewPage.view_risk);
					}
				}catch(Exception e) {
					System.out.println("View Risk option is Not available which is NOT expected");
				}
			}else {
				System.out.println("More than 1 option is available which is NOT expected");
			}
		}
	}

	public static void assigned_to_me_BOM_options(String bOM, String workstream, String product, DataTable Optiondata) throws InterruptedException {

		List<Map<String, String>> optiondata =Optiondata.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = optiondata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(optiondata.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		By ele=By.xpath("//*[@id='jsListView']/div[2]/div/div[4]/table/tbody"
				+ "//td[text()='"+workstream+"']/..//td[text()='"+product+"']/..//td[text()='"+bOM+"']/..//button");
		ReusableMethods.click(ele);
		ReusableMethods.waitForLoad();
		List<String> expected=new ArrayList<String>();
		int options_size=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div[4]/table/tbody"
				+ "//td[text()='"+workstream+"']/..//td[text()='"+product+"']/..//td[text()='"+bOM+"']/..//button/..//a")).size();
		for(int i=1;i<=options_size;i++) {
			String option_value=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/tbody"
					+ "//td[text()='"+workstream+"']/..//td[text()='"+product+"']/..//td[text()='"+bOM+"']/..//button/..//a)["+i+"]")).getText().trim();
			expected.add(option_value);
		}
		/*List<String> actual=new ArrayList<String>();
			int size = optiondata.size();
			for (int anchor = 0; anchor < size; anchor++) {
				actual.add(optiondata.get(anchor));

			}*/
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

	}

	public static void assigned_to_me_applicable_filter_options() {
		ReusableMethods.IsElementExists(AssignedToMePage.bom_risk_search_button,true, "Assigned to Me Search Icon");
		ReusableMethods.IsElementExists(AssignedToMePage.bulk_update_chklall,true,"Assigned to Me Search All Icon");
		ReusableMethods.IsElementExists(AssignedToMePage.filter,true,"Assigned to Me Filter Icon");
		ReusableMethods.IsElementExists(AssignedToMePage.bulkupdate,true,"Assigned to Me Bulk Edit Icon");
		ReusableMethods.IsElementExists(AssignedToMePage.state,true,"Assigned to Me State");
		ReusableMethods.IsElementExists(AssignedToMePage.change_due_dt,true,"Assigned to Me Change due date");
		ReusableMethods.IsElementExists(AssignedToMePage.change_state,true,"Assigned to Me Change State");
		ReusableMethods.IsElementExists(AssignedToMePage.change_assigned_to,true,"Assigned to Me Change Assigned To");
		ReusableMethods.IsElementExists(AssignedToMePage.columnwise_search_button,true,"Assigned to Me Column Search Icon");
		ReusableMethods.IsElementExists(AssignedToMePage.columnwise_search_inputbox,true,"Assigned to Me Column Search Input");		
	}

	public static void options_verification_for_WS(String Workstream, DataTable Options) {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream(Workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.click(DetailedViewPage.workStreamButton);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.total_WS_options)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.total_WS_options+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void options_verification_for_Product(String Product, DataTable Options) throws InterruptedException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setProduct(Product);
		ReusableMethods.click(DetailedViewPage.product);
		ReusableMethods.click(DetailedViewPage.productButton);
		Thread.sleep(2000);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.total_product_options)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.total_product_options+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void options_verification_for_Risk(String risk,String BOM, DataTable Options) throws InterruptedException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setBOM_Risk(BOM,risk);
		ReusableMethods.click(DetailedViewPage.view_editRiskOptionsButton);
		Thread.sleep(2000);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.total_risk_options)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.total_risk_options+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void options_verification_for_BOM(String bOM, DataTable Options) throws InterruptedException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setBOM(bOM);
		ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
		Thread.sleep(2000);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.total_BOM_options)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.total_BOM_options+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void options_verification_for_ALL_WS(DataTable optionsdata) throws InterruptedException {
		List<Map<String, String>> options =optionsdata.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream("All Workstreams");
		ReusableMethods.click(DetailedViewPage.all_workstream);
		ReusableMethods.click(DetailedViewPage.allworkStreamButton);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.allworkStreamoptions)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.allworkStreamoptions+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);		
	}

	public static void options_verification_for_ALL_Products(DataTable optionsdata) throws InterruptedException {
		List<Map<String, String>> options =optionsdata.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream("All Products");
		ReusableMethods.click(DetailedViewPage.all_products);
		ReusableMethods.click(DetailedViewPage.allworkStreamButton);
		Thread.sleep(2000);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.allworkStreamoptions)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.allworkStreamoptions+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);		
	}

	public static void filter_bulkedit_search_options_validations(DataTable filteroptions) throws InterruptedException {
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream("All");
		ReusableMethods.click(DetailedViewPage.allworkStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.IsElementExists(DetailedViewPage.filterIcon,true, "Filter Icon");
		ReusableMethods.IsElementExists(DetailedViewPage.selectall,true,"Select All check box");
		ReusableMethods.IsElementExists(DetailedViewPage.search,true,"Search Icon");
		ReusableMethods.IsElementExists(DetailedViewPage.bulk_edit,true,"Buld edit icon");

		List<Map<String, String>> options =filteroptions.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("FilterOptions"));
		}

		ReusableMethods.click(DetailedViewPage.filterIcon);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.filer_options)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.filer_options+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

		//Apply 1st option in filter 
		driver.findElement(By.xpath("(//li[@ng-if='fltHeader.isFilter']//span/following-sibling::label/..)[1]")).click();
		ReusableMethods.click(DetailedViewPage.filterapply);

		//Check Breadcrumb
		try {
			if(driver.findElement(By.xpath(DetailedViewPage.breadcrumb+"[1]")).isDisplayed()) {
				System.out.println("Breadcromb is getting displayed");
			}			
		}catch(Exception e) {
			System.out.println("Breadcromb is NOT getting displayed");
		}
		ReusableMethods.click(DetailedViewPage.breadcrumb+"[1]");

		ReusableMethods.click(DetailedViewPage.search);
		int search_size=driver.findElements(By.xpath(DetailedViewPage.search_input)).size();
		if(search_size>1) {
			System.out.println("Search Input is getting displayed");
		}else {
			System.out.println("Search Input is NOT getting displayed");
		}

		//Risk Search Option
		ReusableMethods.click(DetailedViewPage.bom_risk_toggle_button);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.IsElementExists(DetailedViewPage.risk_selectall,true,"Select All check box");
		ReusableMethods.IsElementExists(DetailedViewPage.risk_search,true,"Search Icon");
		ReusableMethods.click(DetailedViewPage.risk_search);
		int n=driver.findElements(By.xpath(DetailedViewPage.search_input)).size();
		if(n>1) {
			System.out.println("Search Input is getting displayed");
		}else {
			System.out.println("Search Input is NOT getting displayed");
		}
	}

	public static void upcoming_milstones_validation(String user) throws InterruptedException {
		ReusableMethods.click(DashboardPage.upcoming_milestones);
		int milestones_size=driver.findElements(By.xpath(DashboardPage.GTM_milestones)).size();
		if(milestones_size>1) {
			ReusableMethods.click(DashboardPage.GTM_milestones+"[1]");
			ReusableMethods.IsElementExists(By.xpath(DashboardPage.GTM_milestone_activities),true,"Milestone Activities");
		}
		int milestone_activities_size=driver.findElements(By.xpath(DashboardPage.GTM_milestone_activities)).size();
		if(milestone_activities_size>1) {
			ReusableMethods.click(DashboardPage.GTM_milestone_activities+"[1]");
			ReusableMethods.IsElementExists(DashboardPage.state_dropdown,true,"Milestone State");
			ReusableMethods.IsElementExists(DashboardPage.milestonesubmit,true,"Milestone Submit");
		}		
	}

	public static void select_tile_in_dashboard(String product, String workstream) throws InterruptedException {
		String dashboard_percentage=driver.findElement(DashboardPage.percentage).getText().split("%")[0].trim();
		String dashboard_red_value=driver.findElement(DashboardPage.red_dashboardcount).getText().split("-")[1].trim();
		String dashboard_green_value=driver.findElement(DashboardPage.green_dashboardcount).getText().split("-")[1].trim();
		String dashboard_yellow_value=driver.findElement(DashboardPage.yellow_dashboardcount).getText().split("-")[1].trim();
		double total=Integer.parseInt(dashboard_red_value)+Integer.parseInt(dashboard_green_value)+Integer.parseInt(dashboard_yellow_value);
		double cal_percent=(Integer.parseInt(dashboard_green_value)*100)/total;
		//cal_percent=(cal_percent*100.00)/100.00;
		if(ReusableMethods.two_decimal_places(cal_percent).contains(dashboard_percentage)) {
			System.out.println("Percentage validation is successful in Dashboard !!!!!!!!!!!");
			System.out.println("Actual Percentage = "+dashboard_percentage+" Calculated Percentage = "+ReusableMethods.two_decimal_places(cal_percent));
		}
		else { 
			System.out.println("Incorrect Percentage value in Dashboard !!!!!!!!!!!");
			System.out.println("Actual Percentage = "+dashboard_percentage+" Calculated Percentage = "+ReusableMethods.two_decimal_places(cal_percent));
		}
		ReusableMethods.waitForLoad();		
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		DashboardPage.setProduct_tile(workstream);
		ReusableMethods.click(DashboardPage.product_tile);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
	}

	public static void select_tile_in_dashboard_FL(String product, String workstream) throws InterruptedException {
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, workstream);
		DashboardPage.setProduct_tile(product);
		ReusableMethods.click(DashboardPage.product_tile);
	}
	public static void validate_summary_status_FL(String Product,String workstream,String Status) throws InterruptedException {
		ReusableMethods.IsElementExists(SummaryStatusPage.edit,true,"Edit Button");
		ReusableMethods.click(SummaryStatusPage.edit);
		ReusableMethods.IsElementExists(SummaryStatusPage.save,true,"Save Button");
		ReusableMethods.IsElementExists(SummaryStatusPage.submit,true,"Submit Button");
		ReusableMethods.IsElementExists(SummaryStatusPage.cancel,true,"Cancel");
		ReusableMethods.IsElementExists(SummaryStatusPage.status,false,"Status Dropdown");
		ReusableMethods.click(SummaryStatusPage.status);
		String tilecolor_class_attribute_value="";
		if(Status.equals("none")) {
			ReusableMethods.click(SummaryStatusPage.none);
			tilecolor_class_attribute_value="panel-heading ng-binding panGrey";
			/*
			 * for none option submit button wont be enabled
			 */
		}
		else if(Status.equals("On Track")) {
			ReusableMethods.click(SummaryStatusPage.on_track);
			tilecolor_class_attribute_value="panel-heading ng-binding panGreen";
		}
		else if(Status.equals("Risk")) {
			ReusableMethods.click(SummaryStatusPage.risk);
			tilecolor_class_attribute_value="panel-heading ng-binding panYellow";
		}
		else if(Status.equals("Critical")) {
			ReusableMethods.click(SummaryStatusPage.critical);
			tilecolor_class_attribute_value="panel-heading ng-binding panRed";
		}
		ReusableMethods.click(SummaryStatusPage.submit);
		SummaryStatusPage.setWorkstream(Product);
		String product_completed_data=driver.findElement(By.xpath(SummaryStatusPage.worktream_completed_data)).getText().trim();
		String[] bom_data=product_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		double percent;
		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage=driver.findElement(SummaryStatusPage.completion_percentage).getText().trim();
		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			System.out.println("Percentage validation is successful in Summary status!!!!!!!!!!!");
			System.out.println("Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent);
		}
		else { 
			System.out.println("Incorrect Percentage value in Summary status!!!!!!!!!!!");
			System.out.println("Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent);
		}

		OLAStepDefs.select_page("Dashboard");
		DashboardPage.setProduct_tile_color(Product,tilecolor_class_attribute_value);
		ReusableMethods.IsElementExists(By.xpath(DashboardPage.product_tile_color),true,"Tile after status updated");
	}
	public static void validate_summary_status(String Product,String workstream,String Status) throws InterruptedException {
		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.IsElementExists(SummaryStatusPage.edit,true,"Edit Button");
		ReusableMethods.click(SummaryStatusPage.edit);
		Thread.sleep(2000);
		ReusableMethods.IsElementExists(SummaryStatusPage.save,true,"Save Button");
		ReusableMethods.IsElementExists(SummaryStatusPage.submit,true,"Submit Button");
		ReusableMethods.IsElementExists(SummaryStatusPage.cancel,true,"Cancel");
		ReusableMethods.IsElementExists(SummaryStatusPage.status,false,"Status Dropdown");		
		ReusableMethods.click(SummaryStatusPage.submit);
		Thread.sleep(2000);

		//SummaryStatusPage.setWorkstream(workstream);
		String workstream_completed_data=driver.findElement(By.xpath(SummaryStatusPage.worktream_completed_data)).getText().trim();
		String[] bom_data=workstream_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		double percent;
		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage=driver.findElement(SummaryStatusPage.completion_percentage).getText().trim();
		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			System.out.println("Percentage validation is successful in Summary status!!!!!!!!!!!");
			System.out.println("Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent);
		}
		else { 
			System.out.println("Incorrect Percentage value in Summary status!!!!!!!!!!!");
			System.out.println("Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent);
		}
	}

	public static void validate_scorecard(String product, String Status) throws InterruptedException {
		OLAStepDefs.select_page("Scorecard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		ReusableMethods.IsElementExists(ScoreCardPage.progress,true,"Scorecard Progress");
		ReusableMethods.IsElementExists(ScoreCardPage.scorecardapprover,true,"Scorecard  Approver");
		ReusableMethods.IsElementExists(ScoreCardPage.calendar,true,"Calendar");
		ReusableMethods.IsElementExists(ScoreCardPage.download,true,"Download");
		ReusableMethods.IsElementExists(ScoreCardPage.status_update,true,"Status Update");
		ReusableMethods.click(ScoreCardPage.calendar);
		Thread.sleep(1000);
		driver.findElement(ScoreCardPage.date).sendKeys("31-12-2022");
		ReusableMethods.IsElementExists(ScoreCardPage.clear,true,"Clear");
		ReusableMethods.click(ScoreCardPage.apply);
		ReusableMethods.IsElementExists(ScoreCardPage.highlight_changes_since,true,"Highlight Changes Since");
		ReusableMethods.click(ScoreCardPage.status_update);
		ReusableMethods.click(ScoreCardPage.tracking_status);

		if(Status.equals("none")) {
			ReusableMethods.click(ScoreCardPage.none);
		}
		else if(Status.equals("On Track")) {
			ReusableMethods.click(ScoreCardPage.on_track);
		}
		else if(Status.equals("Risk")) {
			ReusableMethods.click(ScoreCardPage.risk);
		}
		else if(Status.equals("Critical")) {
			ReusableMethods.click(ScoreCardPage.critical);
		}
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.workstream_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.pm_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.gm_approval, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.submit_to_NPI, "Completed");
		ReusableMethods.IsElementExists(ScoreCardPage.submit,true,"Submit");
		ReusableMethods.IsElementExists(ScoreCardPage.save,true,"Save");
		ReusableMethods.click(ScoreCardPage.submit);
	}

	public static void validate_summary_status_BOM_cat(String product, String workstream) throws InterruptedException {
		OLAStepDefs.select_page("Summary Status");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		int cat_size=driver.findElements(By.xpath(SummaryStatusPage.summary_bom_cat_values)).size();
		HashMap<String,String> summary_bom = new HashMap<String,String>();
		HashMap<String,String> dashboard_bom = new HashMap<String,String>();
		for (int i=1;i<=cat_size;i++) {
			String val=driver.findElement(By.xpath(SummaryStatusPage.summary_bom_cat_values+"["+i+"]")).getText().trim();
			summary_bom.put("BOM -"+i, val);			
		}
		OLAStepDefs.select_page("Dashboard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

		if(cat_size>4) {
			for (int i=1;i<=(cat_size/4)+1;i++) {
				try {
					if(driver.findElement(By.xpath(DashboardPage.dashboard_arrow)).isDisplayed()){
						DashboardPage.setProduct_tile(workstream);
						int size=driver.findElements(By.xpath(DashboardPage.dashboard_bom_cat_values)).size();
						for(int j=1;j<=size;j++) {
							String val1=driver.findElement(By.xpath(DashboardPage.dashboard_bom_cat_values+"["+j+"]")).getText().trim();
							dashboard_bom.put("BOM -"+j, val1);	
						}
					}
					ReusableMethods.click(By.xpath(DashboardPage.dashboard_arrow));	
				}catch(Exception e) {
					System.out.println("For more than 4 BOM categories Left/right arrow is not available in dashboard Product/Workstream tile!!");
				}
			}
		}else {
			System.out.println("Les than or equal to 4 BOM categories!!");
			DashboardPage.setProduct_tile(product);
			int size=driver.findElements(By.xpath(DashboardPage.dashboard_bom_cat_values)).size();
			for(int j=1;j<=size;j++) {
				String val1=driver.findElement(By.xpath(DashboardPage.dashboard_bom_cat_values+"["+j+"]")).getText().trim();
				dashboard_bom.put("BOM -"+j, val1);	
			}
		}
		boolean result=summary_bom.equals(dashboard_bom);
		ReusableMethods.softAssertverification(result, true);
	}
	
	public static void select_checkbox(String workstream, DataTable bOMdata) throws InterruptedException {
        List<Map<String, String>> riskData =bOMdata.asMaps(String.class, String.class);
        int size = riskData.size();
        ReusableMethods.waitForLoad();
        DetailedViewPage.setWorkstream(workstream);
        ReusableMethods.click(DetailedViewPage.workStream);    
        ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
        for (int anchor = 0; anchor < size; anchor++) {
            Map<String,String> riskData1 = riskData.get(anchor);
            

            HashMap<String,String> input_data = new HashMap<String,String>();
            try {
                if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
                    int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
                    for(int j=2;j<=page_count-1;j++ ) {
                        By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
                        ReusableMethods.click(page);
                        int n=driver.findElements(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])")).size();        
                        for(int i=1;i<=n;i++) {
                            String bom_name=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])["+i+"]")).getText().trim();
                            String status=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[9])["+i+"]")).getText().trim();
                            String state=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[8])["+i+"]")).getText().trim();
                           if(((bom_name.equals(riskData1.get("BOMName")))&& (status.equals(riskData1.get("Status"))))&& (state.equals(riskData1.get("State")))) {
                               DetailedViewPage.select_checkbox(bom_name);
                               ReusableMethods.click(DetailedViewPage.BOM_checkbox);    
                           }
                        }
                    }
                }                    
            }catch (Exception e) {
                System.out.println("Only one page is there!!");                
                int n=driver.findElements(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])")).size();        
                for(int i=1;i<=n;i++) {
                    String bom_name=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])["+i+"]")).getText().trim();
                    String status=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[9])["+i+"]")).getText().trim();
                    String state=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[8])["+i+"]")).getText().trim();
                    if(((bom_name.equals(riskData1.get("BOMName")))&& (status.equals(riskData1.get("Status"))))&& (state.equals(riskData1.get("State")))) {
                           DetailedViewPage.select_checkbox(bom_name);
                           ReusableMethods.click(DetailedViewPage.BOM_checkbox);
                           Thread.sleep(10000);
                           break;
                   }
                }
            }
        }
	}
        
        public static void select_bom_checkbox(DataTable bOMdata) throws InterruptedException {
            List<Map<String, String>> riskData =bOMdata.asMaps(String.class, String.class);
            int size = riskData.size();
            ReusableMethods.waitForLoad();
            for (int anchor = 0; anchor < size; anchor++) {
                Map<String,String> riskData1 = riskData.get(anchor);
                
                
    
                try {
                    if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
                        int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
                        for(int j=2;j<=page_count-1;j++ ) {
                            By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
                            ReusableMethods.click(page);
                            int n=driver.findElements(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/tbody//td[8])")).size();        
                            for(int i=1;i<=n;i++) {
                                String bom_name=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/tbody//td[8])["+i+"]")).getText().trim();
                                String status=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/tbody//td[11])["+i+"]")).getText().trim();
                                String state=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/tbody//td[10])["+i+"]")).getText().trim();
                               if(((bom_name.equals(riskData1.get("BOMName")))&& (status.equals(riskData1.get("Status"))))&& (state.equals(riskData1.get("State")))) {
                                   AssignedToMePage.select_bom_checkbox(bom_name);
                                   ReusableMethods.click(AssignedToMePage.BOM_checkbox);    
                               }
                            }
                        }
                    }                    
                }catch (Exception e) {
                    System.out.println("Only one page is there!!");                
                    int n=driver.findElements(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/tbody//td[8])")).size();        
                    for(int i=1;i<=n;i++) {
                        String bom_name=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/tbody//td[8])["+i+"]")).getText().trim();
                        String status=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/tbody//td[11])["+i+"]")).getText().trim();
                        String state=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/tbody//td[10])["+i+"]")).getText().trim();
                       if(((bom_name.equals(riskData1.get("BOMName")))&& (status.equals(riskData1.get("Status"))))&& (state.equals(riskData1.get("State")))) {
                           AssignedToMePage.select_bom_checkbox(bom_name);
                           ReusableMethods.click(AssignedToMePage.BOM_checkbox);    
                       }
                    }
                }
            }
    }
}
