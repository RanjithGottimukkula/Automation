package pageObjects;

import org.openqa.selenium.By;

public class ScoreCardPage {
	public static String impersonateUser;
	public static final By progress = By.xpath("//div[@class='scoreProgressContainer']");
	public static final By calendar = By.xpath("//button[@title='Calendar']");
	public static final By download = By.xpath("//button[@title='Download']");
	public static final By status_update = By.xpath("//button[@title='Status Update']");
	public static final By date = By.xpath("//input[@id='dateSelect']");
	public static final By clear = By.xpath("//button[@class='btn btn-outline clrRed']");
	public static final By apply=By.xpath("//*[@id='dateFilterScoreCardModal']//button[contains(text(),'Apply')]");
	public static final By highlight_changes_since=By.xpath("//span[contains(text(),'Highlight Changes Since')]");
	public static final By tracking_status=By.xpath("//div[@class='dropdown custDropSelect']/button");
	public static final By none=By.xpath("//div[@class='dropdown custDropSelect open']/..//li[contains(text(),'none')]");
	public static final By on_track=By.xpath("//div[@class='dropdown custDropSelect open']/..//li[contains(text(),'On Track')]");
	public static final By risk=By.xpath("//div[@class='dropdown custDropSelect open']/..//li[contains(text(),'Risk')]");
	public static final By critical=By.xpath("//div[@class='dropdown custDropSelect open']/..//li[contains(text(),'Critical')]");
	public static final By scorecardapprover=By.xpath("(//div[@class='scoreCardHeader'])[1]");
	public static final By workstream_review=By.xpath("(//*[@id='filterScoreCardModal']//select)[1]");
	public static final By pm_review=By.xpath("(//*[@id='filterScoreCardModal']//select)[2]");
	public static final By gm_approval=By.xpath("(//*[@id='filterScoreCardModal']//select)[3]");
	public static final By submit_to_NPI=By.xpath("(//*[@id='filterScoreCardModal']//select)[4]");
	public static final By submit=By.xpath("//div[@class='modal-footer']//button[contains(text(),'Submit')]");
	public static final By save=By.xpath("//div[@class='modal-footer']//button[contains(text(),'Save')]");
	
	public static void setImpersonateUser(String user) {
		impersonateUser="//div[text()='"+user+"']/..";
	}
	
}
