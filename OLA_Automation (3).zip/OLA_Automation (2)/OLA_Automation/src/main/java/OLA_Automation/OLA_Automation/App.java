package OLA_Automation.OLA_Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * Hello world!
 *
 */

public class App 
{
	@Test
	//public static void main( String[] args ) throws InterruptedException
	public void demo() throws InterruptedException
    {
        System.out.println( "*********************OLA Automation Feasibility*********************" );
        WebDriverManager.chromedriver().setup();
        WebDriver driver=new ChromeDriver();
    	//System.setProperty("windows.chrome.driver","C:\\Driver\\chromedriver.exe");
        driver.get("https://olasandbox.service-now.com");
    	String username="admin_npi";
    	String password="Iopex@123";
    	Thread.sleep(1000);
    	driver.manage().window().maximize();
    	driver.switchTo().frame("gsft_main");
    	Thread.sleep(1000);
    	driver.findElement(By.id("user_name")).sendKeys(username);
    	driver.findElement(By.id("user_password")).sendKeys(password);
    	driver.findElement(By.xpath("//button[@id='sysverb_login']")).click();
    	//impersonate 
    	//driver.get("https://olasandbox.service-now.com/ola");
    	driver.findElement(By.xpath("//button[@id='user_info_dropdown']")).click();
    	WebElement ele=driver.findElement(By.xpath("//html//body//*[@id='glide_ui_impersonator']"));
    	JavascriptExecutor js=(JavascriptExecutor)driver;
    	js.executeScript("arguments[0].click();", ele);
    	driver.findElement(By.xpath("//span[text()='Search for user']/..")).click();
    	driver.findElement(By.xpath("//input[@id='s2id_autogen2_search']")).click();
    	driver.findElement(By.xpath("//input[@id='s2id_autogen2_search']")).sendKeys("GTM Lead");
    	driver.findElement(By.xpath("//div[text()='GTM Lead']/..")).click();	
    	driver.get("https://olasandbox.service-now.com/ola");
    	driver.findElement(By.xpath("//*[text()='Tokyo']")).click();
    	driver.findElement(By.xpath("//button[text()='GTM']")).click();
    	driver.findElement(By.xpath("//*[contains(text(),'Deliverables Overview')]")).click();
    	
    }
}
