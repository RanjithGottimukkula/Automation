package OLA_Automation.OLA_Automation.supportLibraries;



import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class ReusableMethods {
	private WebDriver driver;

	/**
	 * Constructor to initialize the {@link ReusableMethods} object
	 * 
	 * @param driver
	 *            The {@link WebDriver} object
	 */
	public ReusableMethods(WebDriver driver) {
		this.driver = driver;
	}

	public void enterData(By element, String value) {
		explicitWait(element);
		driver.findElement(element).click();
		driver.findElement(element).sendKeys(value);		
	}

	public void click(By element) {
		explicitWait(element);
		driver.findElement(element).click();	
	}

	public void clickJS(By element) {
		explicitWait(element);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", element);
	}

	public void click(String xpath) {
		driver.findElement(By.xpath(xpath)).click();
	}

	public void explicitWait(By element) {
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(50));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(element)));
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(element)));
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);		
	}

	public void selectDataByVisibleText(By element, String value) {
		explicitWait(element);
		Select select=new Select(driver.findElement(element));
		select.selectByVisibleText(value);		
	}
}
