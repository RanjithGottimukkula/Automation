package OLA_Automation.OLA_Automation.supportLibraries;

public enum MobileToolName {

	/**
	 * Use Appium for execution
	 */
	APPIUM,

}
