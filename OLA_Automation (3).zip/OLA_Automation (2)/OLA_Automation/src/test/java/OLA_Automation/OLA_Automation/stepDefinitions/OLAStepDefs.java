package OLA_Automation.OLA_Automation.stepDefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.Base64;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import OLA_Automation.OLA_Automation.pageObjects.OLAPages;
import OLA_Automation.OLA_Automation.supportLibraries.DriverManager;
import OLA_Automation.OLA_Automation.supportLibraries.ReusableMethods;
import OLA_Automation.OLA_Automation.supportLibraries.Settings;
import OLA_Automation.OLA_Automation.supportLibraries.Util;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OLAStepDefs extends MasterStepDefs {
	private static Properties properties;
	private static OLAPages ola_repo;
	private static ReusableMethods reusable_lib;
	static Logger log = Logger.getLogger(OLAStepDefs.class);
	WebDriver driver = DriverManager.getWebDriver();
	
	@When("^I login using the valid username and the valid password$")
	public void i_login_using_valid_username_valid_password() {
		login();
	}
		
	public void login() {
		properties = Settings.getInstance();
		String username = properties.getProperty("Username");
		String password = properties.getProperty("Password");
		byte[] encodedBytes = Base64.getEncoder().encode(password.getBytes());
		
		System.out.println("Encoded Passsword --------------->" + new String(encodedBytes));
		driver.switchTo().frame("gsft_main");
		reusable_lib.enterData(ola_repo.username,username);
		reusable_lib.enterData(ola_repo.password,new String(encodedBytes));

		currentScenario.embed(Util.takeScreenshot(driver),
				"image/png");

		reusable_lib.click(ola_repo.login);
	}
	
	@Then("^Impersonate to \"([^\"]*)\" user$")
	public void impersonate_user(String user) {
		reusable_lib.click(ola_repo.user_dropdown);
		By ele=By.xpath("//html//body//*[@id='glide_ui_impersonator']");
    	reusable_lib.clickJS(ele);
    	reusable_lib.click(ola_repo.search_for_user);
    	reusable_lib.enterData(ola_repo.user_search_input,user);
    	ola_repo.set_impersonate_user(user);
    	reusable_lib.click(ola_repo.impersonate_user);	
	}

	@Then("^Select \"([^\"]*)\" release")
	public void select_release(String release)
	{
    	driver.get("https://olasandbox.service-now.com/ola");
    	driver.findElement(By.xpath("//*[text()='"+release+"']")).click();
    	reusable_lib.click(ola_repo.GTM);
    	reusable_lib.click(ola_repo.deliverables_overview);
	}
	@Then("^Add BOM$")
	public void add_BOM() {
		String workstream="";
		ola_repo.set_impersonate_user(workstream);
    	reusable_lib.click(ola_repo.workstream);
    	reusable_lib.click(ola_repo.workstream_button);
    	reusable_lib.click(ola_repo.workstream_add_BOM);
    	reusable_lib.enterData(ola_repo.BOM_short_desc,"");
    	reusable_lib.enterData(ola_repo.BOM_desc,"");
    	reusable_lib.selectDataByVisibleText(ola_repo.BOM_type,"");
    	reusable_lib.selectDataByVisibleText(ola_repo.BOM_state,"");
    	reusable_lib.selectDataByVisibleText(ola_repo.BOM_category,"");
    	reusable_lib.enterData(ola_repo.BOM_due_date,"");
    	reusable_lib.click(ola_repo.add_button);
    	String message=driver.findElement(ola_repo.added_message).getText();
    	SoftAssert softassert=new SoftAssert();
    	softassert.assertEquals(message, "Custom BOM Added.","BOM added succesfully");
    	reusable_lib.click(ola_repo.close_message);
	}
	@And("^Add Risk to existing BOM$")
	public void add_risk_to_existing_BOM() {
		String BOM="";
		ola_repo.setBOM(BOM);
		reusable_lib.click(ola_repo.added_BOM_options_button);
		reusable_lib.click(ola_repo.add_Risk_to_BOM);
		reusable_lib.enterData(ola_repo.BOM_short_desc,"");
    	reusable_lib.enterData(ola_repo.BOM_desc,"");
    	reusable_lib.selectDataByVisibleText(ola_repo.Risk_impact,"");
    	reusable_lib.selectDataByVisibleText(ola_repo.Risk_status,"");
    	reusable_lib.enterData(ola_repo.BOM_due_date,"");
    	reusable_lib.click(ola_repo.add_button);
    	String message=driver.findElement(ola_repo.added_message).getText();
    	SoftAssert softassert=new SoftAssert();
    	softassert.assertEquals(message, " Risk Submitted! ","Risk added succesfully");
    	reusable_lib.click(ola_repo.close_message);   	
	}	
}
