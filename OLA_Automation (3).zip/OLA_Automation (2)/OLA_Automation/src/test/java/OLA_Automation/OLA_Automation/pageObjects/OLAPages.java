package OLA_Automation.OLA_Automation.pageObjects;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import OLA_Automation.OLA_Automation.stepDefinitions.MasterStepDefs;
import OLA_Automation.OLA_Automation.supportLibraries.DriverManager;

import io.appium.java_client.AppiumDriver;


public class OLAPages {

	public static final By username = By.id("user_name");
	public static final By password = By.id("user_password");
	public static final By login = By.xpath("//button[@id='sysverb_login']");
	public static final By user_dropdown = By.xpath("//button[@id='user_info_dropdown']");
	public static final By search_for_user = By.xpath("//span[text()='Search for user']/..");
	public static final By user_search_input = By.xpath("//input[@id='s2id_autogen2_search']");
	public static String impersonate_user;
	public void set_impersonate_user(String user) {
		impersonate_user="//div[text()='"+user+"']/..";
	}
	public static final By GTM =By.xpath("//button[text()='GTM']");
	public static final By deliverables_overview = By.xpath("//*[contains(text(),'Deliverables Overview')]");
	public static String workstream,workstream_button,workstream_add_BOM,workstream_add_Risk;
	public void set_workstream(String workstream_value) {
		workstream="//h5[text()='"+workstream_value+"']";
		workstream_button="//h5[text()='"+workstream_value+"']/../..//button";
		workstream_add_BOM="//h5[text()='"+workstream_value+"']/../..//button/..//a[text()='Add BOM']";
		workstream_add_Risk="//h5[text()='"+workstream_value+"']/../..//button/..//a[text()='Add Risk']";
	}
	public static final By BOM_short_desc=By.xpath("//textarea[@id='BomShortDescription']");
	public static final By BOM_desc=By.xpath("//textarea[@id='BomDescription' and @ng-model='c.Desc']");
	public static final By BOM_category=By.xpath("//select[@ng-model='c.newbomcat_value']");
	public static final By BOM_partner=By.xpath("//select[@ng-model='c.newpartner_value']");
	public static final By BOM_type=By.xpath("//select[@ng-model='c.newbomtype_value']");
	public static final By BOM_state=By.xpath("//select[@ng-model='c.newstate_value']");
	public static final By BOM_due_date=By.xpath("//input[@id='sp_formfield_' and @ng-model='formattedDate']");//04/28/2022
	public static final By ok_button=By.xpath("//button[text()='OK']");
	public static final By add_button=By.xpath("//button[@id='insert_btn']");
	public static final By added_message=By.xpath("//div[@id='modalrecord']");//Custom BOM Added. 
	public static final By close_message=By.xpath("//button[@aria-label='Close modal']");
	public static String added_BOM_options_button,add_Risk_to_BOM,add_Dependency_to_BOM;
	public void setBOM(String value){
		added_BOM_options_button="//td[text()='"+value+"']/..//button";
		add_Risk_to_BOM="//td[text()='"+value+"']/..//button/..//a[text()='Add Risk']";
		add_Dependency_to_BOM="//td[text()='"+value+"']/..//button/..//a[text()='Add a Dependency']";
	}
	
	public static final By Risk_impact=By.xpath("//select[@ng-model='c.impact']");
	public static final By Risk_status=By.xpath("//select[@ng-model='c.risk_status']");
	

}

