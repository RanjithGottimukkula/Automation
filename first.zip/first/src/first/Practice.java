package first;
import java.util.*;


public class Practice {
	
	public static void main (String args[] ) {
		
		LinkedList<String> li = new LinkedList<String> ();
		li.add("OLA");
		li.add("Red");
		li.add("Yellow");
		li.add("Green");
		li.add("Risk");
		li.add("Bom");
		li.add("Dependency");
		li.add("Npi");
		li.add("Gtm");
		li.add("Fl");		
		System.out.println("Offer Lifecycle Application: " + li);
		li.remove(4);
		System.out.println("Offer Lifecycle Application: " + li);
		li.addFirst("Product");
		li.addLast("Workstream");
		System.out.println("Offer Lifecycle Application: " + li);
		
		   
	    List<String> list = new ArrayList<String>(li);
	    for (String str : list){
	      System.out.println(str);
	    }
	    
	    
	    Iterator i=li.descendingIterator();  
        while(i.hasNext())  
        {  
            System.out.println(i.next());  
        }  

		
        li.removeFirst();
        li.removeLast();
        System.out.println("Offer Lifecycle Application: " + li);
        
        li.add(0,"Servicenow");
        System.out.println("Offer Lifecycle Application: " + li);
        
        Object first_element = li.getFirst();
        System.out.println("First Element is: "+first_element);
        
        Object last_element = li.getLast();
        System.out.println("Last Element is: "+last_element);
        
        for(int p=0; p<li.size(); p++)
        {
           System.out.println("Element at index "+p+": "+li.get(p));
         } 
        
        Collections.reverse(li);
        System.out.println("List after reversing :" + li); 
        
        Collections.swap(li, 0, 2);
        System.out.println("The New linked list after swap: " + li);
        
        Collections.shuffle(li);
        System.out.println("Linked list after shuffling: " + li);
        
        li.removeAll(li);
        System.out.println("Offer Lifecycle Application: " + li);
        
        
		
	}

}
