package first;
import java.util.Scanner;
public class MyClass {
    public static void main(String []args){
  System.out.println("Enter Product name:");
  Scanner sc= new Scanner(System.in); 
  String pro= sc.nextLine();
  System.out.println("Enter Workstream name:");
  String ws= sc.nextLine();
  if(pro.equals("ITOM") && ws.equals("product readiness")){
        System.out.println("Steve Anderson");
}
if(pro.equals("ITOM") && ws.equals("ready to operate")){
        System.out.println("Matt Petschauer Hillary Jones");
        
        
}
}
}