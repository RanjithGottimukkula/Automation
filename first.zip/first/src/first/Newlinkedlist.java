package first;
import java.util.*;

public class Newlinkedlist {
	
	public static void main(String[] args) {
		  LinkedList <String> l1 = new LinkedList <String> ();
		          l1.add("Red");
		          l1.add("Yellow");
		          l1.add("Green");
		          l1.add("Risk");
		          System.out.println("List of first linked list: " + l1);
		          
		 LinkedList <String> l2 = new LinkedList <String> ();
		          l2.add("Dependency");
		          l2.add("Product");
		          l2.add("Workstream");
		          l2.add("Status");
		          System.out.println("List of second linked list: " + l2);
		        
		        LinkedList <String> a = new LinkedList <String> ();
		        a.addAll(l1);
		        a.addAll(l2);
		        System.out.println("New linked list: " + a);
		        
		        
		        LinkedList <String> b = new LinkedList <String> ();
		        b.remove(a);
		        System.out.println("New linked list: " + b);
		        
		             }

}
