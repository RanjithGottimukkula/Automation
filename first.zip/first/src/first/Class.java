package first;

import java.util.*;
public class Class {

   public static void main(String args[]) {
     ArrayList<ArrayList<String> > row = new ArrayList<ArrayList<String> >();
     ArrayList<String> col = new ArrayList<String>();
     
    row.add(new ArrayList<String>());
     row.get(0).add("CSDM");							//BOM Category
     row.get(0).add("CSDM Whitepaper 4.0");				//BOM Name
     row.get(0).add("Read-Only");						//Assigned to
     row.get(0).add("Open");							//State
    
    row.add(new ArrayList<String>());
     row.get(1).add("CSDM");
     row.get(1).add("CSDM Examples");
     row.get(1).add("GTM LEAD");
     row.get(1).add("Complete");
     
     row.add(new ArrayList<String>());
     row.get(2).add("CSDM");
     row.get(2).add("CSDM Framework Mappings");
     row.get(2).add("FL LEAD");
     row.get(2).add("Work In Progress");
     
     row.add(new ArrayList<String>());
     row.get(3).add("CSDM");
     row.get(3).add("CSDM Use Cases");
     row.get(3).add("NPI LEAD");
     row.get(3).add("Not Required");
     
     row.add(new ArrayList<String>());
     row.get(4).add("CSDM");
     row.get(4).add("CSDM Product View");
     row.get(4).add("Read Only");
     row.get(4).add("Open");
       
       Scanner sc = new Scanner(System.in);
       System.out.println("Enter Row:");
       int r = sc.nextInt();
       System.out.println("Enter Col:");
       int c = sc.nextInt();
       System.out.print("Result:" + row.get(r).get(c));
    
       
   }
}
