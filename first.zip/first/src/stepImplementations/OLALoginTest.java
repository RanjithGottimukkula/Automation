package stepImplementations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OLALoginTest {
	// WebDriver driver;
	
	@Given("^user is on the login page$")
	public void user_is_on_the_login_page() {
		System.out.println("user is on the login page");
	}
	
	@When("^user enters correct \"([^\"]*)\" and correct password$")
	public void user_enters_correct_username_and_correct_password(String username) {
		System.out.println("user enters correct username and correct password" + username);
	}
	
	@Then("^user gets conformation$")
	public void user_gets_conformation() {
		System.out.println("user gets conformation");
	}


}

//\"([^\"]*)\" -String