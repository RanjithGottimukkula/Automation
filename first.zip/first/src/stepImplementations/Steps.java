package stepImplementations;


import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Steps {
    WebDriver driver;
	
    @Given ("^user navigates to the login page by opening google_chrome$")
    public void user_navigates_to_the_login_page_by_opening_google_chrome() {
        }
    
   
    @When ("^user enters correct username and password values$")
    public void user_enters_correct_username_and_password_values() {
    	System.setProperty("webdriver.chrome.driver","C:\\Users\\gottimukkula.ranjith\\Downloads\\chromedriver_win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://olasandbox.service-now.com");
    	driver.switchTo().frame("gsft_main");
        driver.findElement(By.xpath("//*[@id='user_name']")).sendKeys("Admin_npi");
        driver.findElement(By.xpath("//*[@id='user_password']")).sendKeys("AdminIopex@12345");
        driver.findElement(By.xpath("//*[@id='sysverb_login']")).click();
        }
      
    @Then ("^user redirect to homepage$")
    public void user_redirect_to_homepage() {
    	driver.get("https://olasandbox.service-now.com/ola");
    	driver.findElement(By.xpath("//*[@id=\"x66a878ad47bd451084ffc472846d439a\"]/div/section[2]/div/div/div[1]/div[1]/div[3]/p")).click();
    	//Assert.assertTrue(driver.findElement(By.id("conf_message")).getText().contains("success"));
        } 
    
    @After ("^teardown$")
    public void teardown() {
    	driver.close();
    }
    
    
    /*public static void main(String []args) {
        Steps obj = new Steps();
        obj.user_navigates_to_the_login_page_by_opening_google_chrome();
        obj.user_enters_correct_username_and_password_values();
        obj.user_redirect_to_homepage();
        //obj.teardown();
    }*/
    
}