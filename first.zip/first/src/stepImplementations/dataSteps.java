package stepImplementations;


import java.util.List;
import java.util.Map;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class dataSteps {
	
	@Given("^user on the detailed view$") 
	public void user_on_the_detailed_view() {
		System.out.println("user on the detailed view");
	}
	
	@When("^user click on the ellipse$")
	public void user_click_on_the_ellipse() {
		System.out.println("user click on the ellipse");
	}
	
	@And("^click on the add risk enter the data$")
	public void click_on_the_add_risk_enter_the_data(DataTable dataTable) {
		System.out.println(dataTable);
		Object row;
		Object column;
		System.out.println(dataTable.cell(row: 0, column: 1));
		System.out.println(dataTable.asLists());
		System.out.println(dataTable.asMaps);
		List<Map<String, String>> dataMap = dataTable.asMaps();
		System.out.println(dataMap.get(1).get("shortdescription"));
	}
	
	@And("^submit the risk$")
	public void submit_the_risk() {
		System.out.println("submit the risk");
	}
	
	@Then("^a new risk should be created$")
	public void a_new_risk_should_be_created() {
		System.out.println("a new risk should be created");
	}

}
