package cucumberTests;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="/first/features/userLogin.feature",glue="/first/src/stepImplementations/Steps.java")

public class TestRunner {

}
