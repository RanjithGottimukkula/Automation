package stepDefinitions;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import pageObjects.AssignedToMePage;
import pageObjects.DashboardPage;
import pageObjects.DetailedViewPage;
import pageObjects.LoginPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class OLAStepDefs {

	private static DetailedViewPage olaPages = new DetailedViewPage();
	private static ReusableMethods reusableMethods = new ReusableMethods();
	private static Logger log = Logger.getLogger(OLAStepDefs.class);
	static WebDriver driver = DriverManager.getWebDriver();
	public static String workstream_overall_status;
	public static String red_count;//=driver.findElement(AppEngine_DetaileViewPage.red_count).getText();
	public static String green_count;//=driver.findElement(AppEngine_DetaileViewPage.green_count).getText();
	public static String yellow_count;//=driver.findElement(AppEngine_DetaileViewPage.yellow_count).getText();
	public static HashMap<String, String> before_adding_risk;
	public static HashMap<String,String> after_adding_risk;
	
	
	@When("^I login using the valid username and the valid password$")
	public void i_login_using_valid_username_valid_password() throws InterruptedException {
		BOTStepDefs.login();
	}

	@Then("^Impersonate to \"([^\"]*)\" user$")
	public void impersonate_user(String impersonateUser) throws InterruptedException {
		BOTStepDefs.setImpersonateUser(impersonateUser);
	}

	@Then("^Select \"([^\"]*)\" release")
	public void select_release(String release) {
		BOTStepDefs.selectRelease(release);
	}

	@Then("^Add BOM using following details for GTM Lead:$")
	public void add_BOM(DataTable BOMdata) throws InterruptedException {
		BOTStepDefs.addBOM(BOMdata);
	}

	@Then("^Add BOM using following details for Functional Lead:$")
	public void add_BOM_FL(DataTable BOMdata) throws InterruptedException {
		BOTStepDefs.addBOM_FL(BOMdata);
	}

	@Then("^Edit BOM in \"([^\"]*)\" using following details:$")
	public void edit_BOM(String workstream, DataTable BOMdata) throws InterruptedException {
		BOTStepDefs.editBOM(workstream, BOMdata);
	}

	@Then("^Clone BOM in \"([^\"]*)\" using following details:$")
	public void clone_BOM(String workstream, DataTable BOMdata) throws InterruptedException {
		BOTStepDefs.cloneBOM(workstream, BOMdata);
	}

	@And("^Add Risk to BOM \"([^\"]*)\" using following details:$")
	public void add_risk_to_existing_BOM(String BOM,DataTable Riskdata) throws InterruptedException  {
		BOTStepDefs.addrisk_to_existing_BOM(BOM,Riskdata);
	}

	@Then("^Add Risk to Workstream \"([^\"]*)\" using following details:$")
	public void add_risk_to_a_workstream(String workstream,DataTable Riskdata) throws InterruptedException  {	
		ReusableMethods.waitForLoad();
		before_adding_risk=BOTStepDefs.workstream_bom_status_data(workstream);
		BOTStepDefs.addrisk_to_a_workstream(workstream,Riskdata);
		after_adding_risk=BOTStepDefs.workstream_bom_status_data(workstream);
	}
	
	@Then("^Bulk Update in Workstream \"([^\"]*)\" using following details$")
    public void select_checkbox(String workstream, DataTable BOMdata) throws InterruptedException  {
        BOTStepDefs.select_checkbox(workstream, BOMdata);
    }
	
	@Then("^Select bom checkbox using following details$")
	public void select_bom_checkbox(DataTable BOMdata) throws InterruptedException {
		BOTStepDefs.select_bom_checkbox(BOMdata);
	}
	
	@Then("^Select Bulk edit$")
	public void select_Bulk_edit() throws InterruptedException {
		ReusableMethods.click(DetailedViewPage.Bulk_edit);
        Thread.sleep(10000);	
	}
	
	@Then("^Select Workstream \"([^\"]*)\"$")
	public void select_workstream(String Workstream) {
		DetailedViewPage.setWorkstream(Workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		try {
			if (driver.findElement(By.xpath(DetailedViewPage.workStreamButton)).isDisplayed()) {
				System.out.println("Worktream Options are available which is NOT working as expected");
			}		
		}catch(Exception e) {
			System.out.println("Worktream Options are not available which is working as expected");
		}
	}
	
	@Then("^Select Checkbox$")
	public void select_checkbox() throws InterruptedException{
		ReusableMethods.click(DetailedViewPage.select_checkbox);
		Thread.sleep(10000);
	}

	@And("^Edit Risk in \"([^\"]*)\" using following details:$")
	public void edit_risk_to_existing_BOM(String workstream,DataTable Riskdata) throws InterruptedException  {
		BOTStepDefs.editrisk_to_existing_BOM(workstream,Riskdata);
	}

	@And("^Add Dependency to BOM \"([^\"]*)\" using following details:$")
	public void add_dependency_to_existing_BOM(String BOM,DataTable Dependencydata) throws InterruptedException  {
		BOTStepDefs.adddependency_to_existing_BOM(BOM,Dependencydata);
	}

	@And("^validate RYG data in detailed view and dashboard$")
	public void RYG_data_validation() throws InterruptedException {

		Thread.sleep(10000);
		String red_count=driver.findElement(DetailedViewPage.red_count).getText();
		String green_count=driver.findElement(DetailedViewPage.green_count).getText();
		String yellow_count=driver.findElement(DetailedViewPage.yellow_count).getText();
		int y_count=0,r_count=0,g_count=0,open_count=0,wip_count=0,complete_count=0;

		/*
		 * Ignoring navigation in page_count(page_count-2)
		 * Iterating each page and getting the count of RYG
		 */
		int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]//dir-pagination-controls/ul/li/a")).size();
		for(int j=2;j<=page_count-1;j++ ) {
			By page=By.xpath("(//*[@id='jsListView']/div[2]//dir-pagination-controls/ul/li/a)["+j+"]");
			ReusableMethods.click(page);
			int n=driver.findElements(By.xpath("//tbody//td[11]")).size();		
			for(int i=1;i<n;i++) {
				String status_value=driver.findElement(By.xpath("(//tbody//td[11])["+i+"]")).getText();
				if(status_value.contains("Red")) { r_count+=1;}
				else if(status_value.contains("Green")) { g_count+=1;}
				else if(status_value.contains("Yellow")) { y_count+=1;}
				String state_value=driver.findElement(By.xpath("(//tbody//td[10])["+i+"]")).getText();
				if(state_value.contains("Open")) { open_count+=1;}
				else if(state_value.contains("Work in Progress")) { wip_count+=1;}
				else if(state_value.contains("Complete")) { complete_count+=1;}
			}
		}
		/*
		 * Getting data for Not Required
		 */
		ReusableMethods.click(DetailedViewPage.filter);
		ReusableMethods.click(DetailedViewPage.notrequired_filter);
		ReusableMethods.click(DetailedViewPage.apply);
		try {
			if(driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]//dir-pagination-controls/ul/li/a)[1]")).isDisplayed()) {
				int notrequired_page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]//dir-pagination-controls/ul/li/a")).size();
				for(int j=2;j<=notrequired_page_count-1;j++ ) {
					By page=By.xpath("(//*[@id='jsListView']/div[2]//dir-pagination-controls/ul/li/a)["+j+"]");
					ReusableMethods.click(page);
					int n=driver.findElements(By.xpath("//tbody//td[10]")).size();		
					for(int i=1;i<n;i++) {
						String status_value=driver.findElement(By.xpath("(//tbody//td[11])["+i+"]")).getText();
						if(status_value.contains("Red")) { r_count+=1;}
						else if(status_value.contains("Green")) { g_count+=1;}
						else if(status_value.contains("Yellow")) { y_count+=1;}
					}
				}
			}
		}catch(Exception e) {
			System.out.println("Only one page is there!!!!");		
			int n=driver.findElements(By.xpath("//tbody//td[11]")).size();		
			for(int i=1;i<n;i++) {
				String status_value=driver.findElement(By.xpath("(//tbody//td[11])["+i+"]")).getText();
				if(status_value.contains("Red")) { r_count+=1;}
				else if(status_value.contains("Green")) { g_count+=1;}
				else if(status_value.contains("Yellow")) { y_count+=1;}
			}
		}
		int r = 0,y = 0,g = 0;
		double percent;
		ReusableMethods.click(DashboardPage.dashboard);
		Thread.sleep(20000);
		String percentage=driver.findElement(DashboardPage.percentage).getText();
		String dashborad_red_value=driver.findElement(DashboardPage.red_dashboardcount).getText();
		String dashborad_green_value=driver.findElement(DashboardPage.green_dashboardcount).getText();
		String dashborad_yellow_value=driver.findElement(DashboardPage.yellow_dashboardcount).getText();
		if(dashborad_red_value.contains(red_count)) {
			r=Integer.parseInt(red_count);
		}else { System.out.println("Red count mismatched in Detailed View and Dashboard!!!!!!!!!!!");}
		if(dashborad_yellow_value.contains(yellow_count)) {
			y=Integer.parseInt(yellow_count);
		}else { System.out.println("Yellow count mismatched in Detailed View and Dashboard!!!!!!!!!!!");}
		if(dashborad_green_value.contains(green_count)) {
			g=Integer.parseInt(green_count);
		}else { System.out.println("Green count mismatched in Detailed View and Dashboard!!!!!!!!!!!");}
		if(r!=r_count) { System.out.println("Red count mismatched in Detailed View and Table!!!!!!!!!!!");}
		if(y!=y_count) { System.out.println("Yellow count mismatched in Detailed View and Table!!!!!!!!!!!");}
		if(g!=g_count) { System.out.println("Green count mismatched in Detailed View and Table!!!!!!!!!!!");}

		//Complete/(Complete+Open+WIP)
		percent=(complete_count*100)/(complete_count+open_count+wip_count);
		System.out.println("Percentage = "+Math.round(percent*100.0)/100.0);
		percent=Math.round(percent*100.0)/100.0;
		if(percentage.contains(String.valueOf(percent))) {
			System.out.println("Percentage validation is successful in Dashboard!!!!!!!!!!!");
		}
		else { System.out.println("Incorrect Percentage value in Dashboard!!!!!!!!!!!");}
	}

	@Then("^validate RYG data for \"([^\"]*)\" after BOM update$")
	public void validate_RYG_data_for_a_workstream_after_BOM_update(String workstream) {
		String overall,nrq,overall_afterupdate,allworkstreams,allworkstreams_afterupdate;
		overall=BOTStepDefs.getWorkstreamData("Workstream Overall Status");
		nrq=BOTStepDefs.getWorkstreamData("Workstream Not Required Update Count");
		overall_afterupdate=BOTStepDefs.getWorkstreamData("Workstream Overall Status After Update");
		allworkstreams=BOTStepDefs.getWorkstreamData("AllWorkstream Status");
		allworkstreams_afterupdate=BOTStepDefs.getWorkstreamData("AllWorkstream Status After Updatey");
		int overall_val,nrq_val,overall_afterupdate_val,allworkstreams_val,allworkstreams_afterupdate_val,overall_afterupdate_val_expected,allworkstreams_val_expected;
		String[] a=overall_afterupdate.split("/");
		overall_afterupdate_val=Integer.parseInt(a[1]);
		String[] b=overall.split("/");
		overall_val=Integer.parseInt(b[1]);
		nrq_val=Integer.parseInt(nrq);
		overall_afterupdate_val_expected=overall_val-nrq_val;
		if (overall_afterupdate_val_expected==overall_afterupdate_val) {
			ReusableMethods.softAssertverification(true, true);
		}else {
			ReusableMethods.softAssertverification(false, true);
		}

		String[] a1=allworkstreams.split("(");
		allworkstreams_val=Integer.parseInt((a1[1].split(")"))[0]);
		String[] a2=allworkstreams_afterupdate.split("(");
		allworkstreams_afterupdate_val=Integer.parseInt((a2[1].split(")"))[0]);

		allworkstreams_val_expected=allworkstreams_val-nrq_val;
		if (allworkstreams_val_expected==allworkstreams_afterupdate_val) {
			ReusableMethods.softAssertverification(true, true);
		}else {
			ReusableMethods.softAssertverification(false, true);
		}
	}

	@Then("^Add Document using following details:$")
	public void add_document(DataTable data) throws InterruptedException {
		BOTStepDefs.add_document(data);
	}

	@Then("^Remove Document using following details:$")
	public void remove_document(DataTable data) throws InterruptedException {
		BOTStepDefs.remove_document(data);
	}

	@Then("^Verify All Workstreams Column name and order$")
	public void all_workstreams_columnname_and_order() throws InterruptedException {
		//BOM table validation
		List<String> expected=new ArrayList<String>();
		expected.add("Workstream");
		expected.add("BOM Category");
		expected.add("BOM Name");
		expected.add("Assigned To");
		expected.add("State");
		expected.add("Status");
		expected.add("Due Date");
		expected.add("Partner");
		List<String> actual=new ArrayList<String>();
		int n=driver.findElements(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/thead//th)")).size();
		for(int i=5;i<=12;i++) {
			String value=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/thead//th)["+i+"]")).getText();
			value.trim();
			actual.add(value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

		//Risk table validation
		ReusableMethods.click(DetailedViewPage.bom_risk_toggle_button);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		List<String> expected1=new ArrayList<String>();
		expected1.add("Workstream");
		expected1.add("Applicable To");
		expected1.add("Risk Name");
		expected1.add("Assigned To");
		expected1.add("Status");
		expected1.add("Impact");
		expected1.add("Initiate Date");
		expected1.add("Due Date");
		List<String> actual1=new ArrayList<String>();
		for(int i=5;i<=12;i++) {
			String value=driver.findElement(By.xpath("(//*[@id='jsListView']/div[3]/div/div/div[4]/table/thead//th)["+i+"]")).getText();
			value.trim();
			actual1.add(value);
		}
		boolean result1=expected1.equals(actual1);
		ReusableMethods.softAssertverification(result1, true);
	}

	@Then("^Verify Column name and order for the below workstreams:$")
	public void columnname_and_order_verifictaion_for_given_workstream(DataTable data) {
		BOTStepDefs.columnname_and_order_verification_for_a_workstream(data);
	}

	@Then("^Verify Assigned To Me Column name and order$")
	public void verify_assigned_to_me_columnname_and_order() throws InterruptedException {
		//BOM table validation

		ReusableMethods.click(AssignedToMePage.assignedtome);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		List<String> expected=new ArrayList<String>();
		expected.add("Workstream");
		expected.add("Product");
		expected.add("BOM Category");
		expected.add("BOM Name");
		expected.add("Assigned To");
		expected.add("State");
		expected.add("Status");
		expected.add("Due Date");
		expected.add("Partner");
		List<String> actual=new ArrayList<String>();
		int n=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div[4]/table/thead//th")).size();
		for(int i=5;i<=13;i++) {
			String value=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/thead//th)["+i+"]")).getText().trim();
			actual.add(value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

		//Risk table validation
		ReusableMethods.click(AssignedToMePage.bom_risk_toggle_button);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		List<String> expected1=new ArrayList<String>();
		expected1.add("Workstream");
		expected1.add("Product");
		expected1.add("Applicable To");
		expected1.add("Risk Name");
		expected1.add("Assigned To");
		expected1.add("Status");
		expected1.add("Impact");
		expected1.add("Initiate Date");
		expected1.add("Due Date");
		List<String> actual1=new ArrayList<String>();
		for(int i=5;i<=13;i++) {
			String value=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/thead//th)["+i+"]")).getText().trim();
			actual1.add(value);
		}
		boolean result1=expected1.equals(actual1);
		ReusableMethods.softAssertverification(result1, true);
	}

	@And("^Verify options for the below workstreams:$")
	public void verify_options_for_workstreams(DataTable input) {
		BOTStepDefs.options_verification_for_workstreams(input);	
	}

	@And("^Verify below mentioned options in Funtional Lead for \"([^\"]*)\"$")
	public void verify_options_in_FunctionalLead_for_workstreams(String workstream, DataTable options) {
		BOTStepDefs.options_verification_for_workstreams_in_functional_lead(workstream,options);	
	}

	@Then("^validate Red color for BOM \"([^\"]*)\" in \"([^\"]*)\"$")
	public void rule1(String BOM, String Workstream) throws InterruptedException, ParseException {
		BOTStepDefs.RYG_rule1(BOM, Workstream);
	}

	@Then("^validate Risk which should be in \"([^\"]*)\" for BOM \"([^\"]*)\" in \"([^\"]*)\"$")
	public void risk_to_a_bom_rules(String color,String BOM, String Workstream) throws InterruptedException, ParseException {
		BOTStepDefs.RYG_risk_rules(color,BOM, Workstream);
	}
	
	@Then("^validate Risk which should be in \"([^\"]*)\" for Workstream \"([^\"]*)\"$")
	public void risk_to_a_workstream_rules(String color, String Workstream) throws InterruptedException, ParseException {
		HashMap<String,String> rule_applied_values=new HashMap<String,String>();
		String exp_val;
		//Iterator <String> it = expected_values.keySet().iterator();       //keyset is a method  
		//while(it.hasNext())  
		for( String key:before_adding_risk.keySet())
		{   
			//if(!it.next().isEmpty()) { 
			//int key=Integer.parseInt(it.next()); 
			exp_val=before_adding_risk.get(key);
			String[] status_color=exp_val.split("-");
			if(color.equals("Red")) {
				if(status_color[0].equals("Red") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Red");	
				}else {  	rule_applied_values.put(key, status_color[0]);	}
				if(status_color[0].equals("Yellow") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Red");	
				}else {  	rule_applied_values.put(key, status_color[0]);	}
				if(status_color[0].equals("Green") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Red");	
				}else {  	rule_applied_values.put(key, status_color[0]);	}
			}
			if(color.equals("Yellow")) {
				if(status_color[0].equals("Red") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Red");	
				}else {  	rule_applied_values.put(key, status_color[0]);	}
				if(status_color[0].equals("Yellow") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Yellow");	
				}else {  	rule_applied_values.put(key, status_color[0]);	}
				if(status_color[0].equals("Green") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Yellow");	
				}else {  	rule_applied_values.put(key, status_color[0]);	}
			}
			if(color.equals("Green")) {
				if(status_color[0].equals("Red") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Red");	
				}else {  	rule_applied_values.put(key, status_color[0]);	}
				if(status_color[0].equals("Yellow") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Yellow");	
				}else {  	rule_applied_values.put(key, status_color[0]);	}
				if(status_color[0].equals("Green") &&  !status_color[1].equals("Complete")) {
					rule_applied_values.put(key, "Green");	
				}else {  	rule_applied_values.put(key, status_color[0]);	}
			}
		}
		boolean result=rule_applied_values.equals(after_adding_risk);
		ReusableMethods.softAssertverification(result, true);

	}
	@And("^Add New release using following details:$")
	public static void add_newrelease(DataTable releasedata) throws InterruptedException {
		List<Map<String, String>> releases =releasedata.asMaps(String.class, String.class);
		int size = releases.size();
		boolean flag=false;
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> releaseData = releases.get(anchor);
			ReusableMethods.waitForLoad();
			ReusableMethods.click(DashboardPage.add_release);
			ReusableMethods.enterData(DashboardPage.release_name,releaseData.get("ReleaseName"));
			ReusableMethods.enterData(DashboardPage.description,releaseData.get("Description"));
			ReusableMethods.click(DashboardPage.releasetype_dropdown);
			driver.findElement(DashboardPage.releaseSearchInputBox).sendKeys(releaseData.get("ReleaseType"));
			DashboardPage.setReleaseType(releaseData.get("ReleaseType"));
			ReusableMethods.waitForLoad();
			ReusableMethods.click(DashboardPage.releasetype);
			//ReusableMethods.enterData(DashboardPage.start_date,releaseData.get("StartDate"));
			//ReusableMethods.enterData(DashboardPage.end_date,releaseData.get("EndDate"));
			//ReusableMethods.click(DashboardPage.submit);
			ReusableMethods.waitForLoad();
			String name=releaseData.get("ReleaseName");
			try {
				if(driver.findElement(DashboardPage.submit).isDisplayed()) {
					System.out.println("Submit button is getting displayed ");
				}
			}catch(Exception e) {
				System.out.println("Submit button is NOT getting displayed ");
			}
		}
	}
	@Then("^Select Page \"([^\"]*)\"$")
	public static void select_page(String page) throws InterruptedException {
		if(page.equals("Deliverables Overview")) {
			ReusableMethods.click(DetailedViewPage.deliverables_overview);
		}else {
			DashboardPage.setPage(page);
			ReusableMethods.click(DashboardPage.page_name);
		}
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
	}

	@Then("^Select Product/Workstream \"([^\"]*)\"$")
	public void select_product(String name) {
		DashboardPage.setProduct_or_Workstream(name);
		ReusableMethods.click(DashboardPage.product_or_workstream);
	}

	@Then("^Verify actions at Workstream \"([^\"]*)\"$")
	public void workstream_actions(String Workstream) {
		DetailedViewPage.setWorkstream(Workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		try {
			if (driver.findElement(By.xpath(DetailedViewPage.workStreamButton)).isDisplayed()) {
				System.out.println("Worktream Options are available which is NOT working as expected");
			}		
		}catch(Exception e) {
			System.out.println("Worktream Options are not available which is working as expected");
		}
	}

	@Then("^Verify actions at Product \"([^\"]*)\"$")
	public void product_actions(String product) {
		DetailedViewPage.setProduct(product);
		ReusableMethods.click(DetailedViewPage.product);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		try {
			if (driver.findElement(By.xpath(DetailedViewPage.productButton)).isDisplayed()) {
				System.out.println("Product Options are available which is NOT expected");
			}		
		}catch(Exception e) {
			System.out.println("Product Options are NOT available which is expected");
		}
	}

	@And("^Verify below mentioned options in Workstream \"([^\"]*)\"$")
	public void verify_options_in_workstreams(String Workstream, DataTable options) {
		BOTStepDefs.options_verification_for_WS(Workstream,options);	
	}
	
	@And("^Verify below mentioned options in Product \"([^\"]*)\"$")
	public void verify_options_in_product(String Product, DataTable options) throws InterruptedException {
		BOTStepDefs.options_verification_for_Product(Product,options);	
	}

	@And("^Verify only one option in BOM \"([^\"]*)\"$")
	public void verify_one_option_in_BOM_for_workstreams(String BOM, DataTable options) {
		BOTStepDefs.one_option_verification_for_BOM(BOM,options);	
	}

	@And("^Verify only one option in Risk \"([^\"]*)\" for BOM \"([^\"]*)\"$")
	public void verify_one_option_in_Risk_for_workstreams(String Risk,String BOM, DataTable options) {
		BOTStepDefs.one_option_verification_for_Risk(Risk,BOM,options);	
	}

	@And("^Verify below mentioned options in BOM \"([^\"]*)\"$")
	public void verify_options_in_BOM_for_workstreams(String BOM, DataTable options) throws InterruptedException {
		BOTStepDefs.options_verification_for_BOM(BOM,options);	
	}

	@And("^Verify below mentioned options in Risk \"([^\"]*)\" for BOM \"([^\"]*)\"$")
	public void verify_options_in_Risk_for_workstreams(String Risk,String BOM, DataTable options) throws InterruptedException {
		BOTStepDefs.options_verification_for_Risk(Risk,BOM,options);	
	}

	@Then("^Verify below mentioned options for BOM \"([^\"]*)\" in Workstream \"([^\"]*)\" in Product \"([^\"]*)\"$")
	public void assigned_to_me_BOM_options(String BOM, String Workstream, String Product,DataTable data) throws InterruptedException {
		BOTStepDefs.assigned_to_me_BOM_options(BOM,Workstream,Product,data);
	}

	@Then("^Verify Assigned To Me applicable filter options$")
	public void assigned_to_me_applicable_filter_options() {
		BOTStepDefs.assigned_to_me_applicable_filter_options();
	}

	@Then("^Verify All Products Column name and order$")
	public void all_products_columnname_and_order() throws InterruptedException {
		//BOM table validation
		List<String> expected=new ArrayList<String>();
		expected.add("Product");
		expected.add("BOM Category");
		expected.add("BOM Name");
		expected.add("Assigned To");
		expected.add("State");
		expected.add("Status");
		expected.add("Due Date");
		expected.add("Partner");
		List<String> actual=new ArrayList<String>();
		int n=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]/table/thead//th")).size();
		for(int i=5;i<=12;i++) {
			String value=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/thead//th)["+i+"]")).getText();
			value.trim();
			actual.add(value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

		//Risk table validation
		ReusableMethods.click(DetailedViewPage.bom_risk_toggle_button);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		List<String> expected1=new ArrayList<String>();
		expected1.add("Product");
		expected1.add("Applicable To");
		expected1.add("Risk Name");
		expected1.add("Assigned To");
		expected1.add("Status");
		expected1.add("Impact");
		expected1.add("Initiate Date");
		expected1.add("Due Date");
		List<String> actual1=new ArrayList<String>();
		for(int i=5;i<=12;i++) {
			String value=driver.findElement(By.xpath("(//*[@id='jsListView']/div[3]/div/div/div[4]/table/thead//th)["+i+"]")).getText();
			value.trim();
			actual1.add(value);
		}
		boolean result1=expected1.equals(actual1);
		ReusableMethods.softAssertverification(result1, true);
	}

	@Then("^Verify below mentioned option in All Workstreams$")
	public void all_workstream_options(DataTable Options) throws InterruptedException {
		BOTStepDefs.options_verification_for_ALL_WS(Options);	
	}
	
	@Then("^Verify below mentioned option in All Products$")
	public void all_products_options(DataTable Options) throws InterruptedException {
		BOTStepDefs.options_verification_for_ALL_Products(Options);	
	}
	@Then("^Validate Detailed View page BOM filter,bulkedit and search options and Risk Search option$")
	public void filter_bulkedit_search_options_validations(DataTable filteroptions) throws InterruptedException {
		BOTStepDefs.filter_bulkedit_search_options_validations(filteroptions);
	}
	
	@And("^Verify Upcoming Miletsones for user \"([^\"]*)\"$")
	public void upcoming_milstones_validation(String user) throws InterruptedException {
	BOTStepDefs.upcoming_milstones_validation(user);
	}
	
	@And("^Select Product \"([^\"]*)\" and Workstream \"([^\"]*)\" in Dashboard for Functional Lead$")
	public void select_tile_in_dashboard_FL(String Product,String Workstream) throws InterruptedException {
		BOTStepDefs.select_tile_in_dashboard_FL(Product,Workstream);
	}
	
	@And("^Select Product \"([^\"]*)\" and Workstream \"([^\"]*)\" in Dashboard for GTM Lead$")
	public void select_tile_in_dashboard(String Product,String Workstream) throws InterruptedException {
		BOTStepDefs.select_tile_in_dashboard(Product,Workstream);
	}
	
	@And("^Validate Summary Status for Product \"([^\"]*)\" and Workstream \"([^\"]*)\" with status \"([^\"]*)\" for GTM Lead$")
	public void summary_status_validation_for_given_status(String Product,String Workstream,String status) throws InterruptedException {
		BOTStepDefs.validate_summary_status(Product,Workstream,status);
	}
	
	@And("^Validate Summary Status BOM categories for Product \"([^\"]*)\" and Workstream \"([^\"]*)\" with Dashboard BOM categories for GTM Lead$")
	public void summary_status_BOM_cat_validation(String Product,String Workstream) throws InterruptedException {
		BOTStepDefs.validate_summary_status_BOM_cat(Product,Workstream);
	}
	
	@And("^Validate Summary Status for Product \"([^\"]*)\" and Workstream \"([^\"]*)\" with status \"([^\"]*)\" for Functional Lead$")
	public void summary_status_validation_for_given_status_FL(String Product,String Workstream,String status) throws InterruptedException {
		BOTStepDefs.validate_summary_status_FL(Product,Workstream,status);
	}
	
	@And("^Validate ScoreCard Status for Product \"([^\"]*)\" with status \"([^\"]*)\"$")
	public void scorecard_validation_for_given_status(String Product,String status) throws InterruptedException {
		BOTStepDefs.validate_scorecard(Product,status);
	}
}