package JSONandXMLSchemavalidation;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import PostRequests.Pojo_PostRequest;

//POJO------Serialize--------->JSON Object--------De-serilize----------->POJO

public class SerialisationDeserilisation {

	// POJO -----> JSON(Serialisation)
	//@Test
	public void Serialisation() throws JsonProcessingException {

		// Created java object using POJO class
		SerialisationDeserilisation_Pojo pojo = new SerialisationDeserilisation_Pojo(); // POJO
		pojo.setName("manjunath");
		pojo.setJob("software");

		// Convert java object ---> Json object (Serialisation)
		ObjectMapper OM = new ObjectMapper();
		String jsondata = OM.writerWithDefaultPrettyPrinter().writeValueAsString(pojo);
		System.out.println(jsondata);
	}

	// POJO -----> JSON(Serialisation)
	@Test
	public void DeSerialisation() throws JsonProcessingException {
		
		String jsondata = "{\r\n"
				+ "  \"name\" : \"manjunath\",\r\n"
				+ "  \"job\" : \"software\"\r\n"
				+ "}";
		
		// Convert JSON ---> POJO object (De-serialisation)
		ObjectMapper OM = new ObjectMapper();
		
		//Convert JSON to POJO
		SerialisationDeserilisation_Pojo str = OM.readValue(jsondata, SerialisationDeserilisation_Pojo.class);
		
		System.out.println("Name"+"--"+str.getName());
		System.out.println("Job"+"--"+str.getJob());

	}

}
