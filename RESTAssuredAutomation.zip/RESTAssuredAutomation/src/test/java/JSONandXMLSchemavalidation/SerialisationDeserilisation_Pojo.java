package JSONandXMLSchemavalidation;

public class SerialisationDeserilisation_Pojo {
	
	String name;
	String job;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}

}
