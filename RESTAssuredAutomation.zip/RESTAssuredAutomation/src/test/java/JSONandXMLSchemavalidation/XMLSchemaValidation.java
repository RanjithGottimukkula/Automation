package JSONandXMLSchemavalidation;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.matcher.RestAssuredMatchers;

public class XMLSchemaValidation {
	
	@Test
	public void xmschemavalidation() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		given()
		
		.when()
			.get("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.xml")
		
		.then()
			.statusCode(200)
			.assertThat().body(RestAssuredMatchers.matchesXsdInClasspath("storeXmlSchema.xsd"));
	}

}
