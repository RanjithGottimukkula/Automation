package ParsingXMLResponseBody;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class ParsingXMLResponse {
	
	@Test(priority=1)
	public void testXMLResponse() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		//Approach 1
		/*given()
		
		.when()
			.get("http://restapi.adequateshop.com/api/Traveler?page=1")
		
		.then()
			.statusCode(200)
			.header("Content-Type", "appication/xml; charset=utf-8")
			.body("TravelerinformationResponse.page", equalTo(1))
			.body("TravelerinformationResponse.travelers.Travelerinformation[0].name", equalTo("Vijay Bharath Reddy"));
		*/
		
		//Approach 2
		Response res = 
		given()
		
		.when()
			.get("http://restapi.adequateshop.com/api/Traveler?page=1");
		
		Assert.assertEquals(res.getStatusCode(), 200);
		Assert.assertEquals(res.getContentType(), "appication/xml; charset=utf-8");
		
		String pageNo = res.xmlPath().get("TravelerinformationResponse.page").toString();
		Assert.assertEquals(pageNo, 1);
		
		String travelName = res.xmlPath().get("TravelerinformationResponse.travelers.Travelerinformation[0].name").toString();
		Assert.assertEquals(travelName, "Vijay Bharath Reddy");
		
	}
	
	@Test(priority=2)
	public void testXMLResponseBody() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		Response res = 
		given()
		
		.when()
			.get("http://restapi.adequateshop.com/api/Traveler?page=1");
		
		XmlPath xp = new XmlPath(res.asString());
		
		//Verify total number of travelers
		List<String> travelers = xp.getList("TravelerinformationResponse.travelers.Travelerinformation");
		Assert.assertEquals(travelers.size(), 10);
		
		//Verify traveler name present in response
		List<String> travelersNames = xp.getList("TravelerinformationResponse.travelers.Travelerinformation.name");
		
		boolean status = false;
		for(String travelerName : travelersNames) {
			
			if(travelerName.equals("Vijay Bharath Reddy")) {
				status=true;
				break;
			}
		}
		
		Assert.assertEquals(status, true);
		
	}
	

}
