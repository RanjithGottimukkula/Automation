package ParsingXMLResponseBody;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class FileUploadAndDownload {
	
	@Test
	public void singleFileUpload() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		File myfile = new File("C:\\Users\\gottimukkula.ranjith\\Downloads\\text1.txt");
		
		given()
			.multiPart("file", myfile)
			.contentType("multiPart/form-data")
		
		.when()
			.post("https://localhost:8080/uploadFile")
		
		.then()
			.statusCode(200)
			.body("fileName", equalTo("Test1.txt"))
			.log().all();
	}
	
	@Test
	public void multipleFileUpload() {
		
		File myfile1 = new File("C:\\Users\\gottimukkula.ranjith\\Downloads\\text1.txt");
		File myfile2 = new File("C:\\Users\\gottimukkula.ranjith\\Downloads\\text2.txt");
		
		given()
			.multiPart("files", myfile1)
			.multiPart("files", myfile2)
			.contentType("multiPart/form-data")
		
		.when()
			.post("https://localhost:8080/uploadMultipleFiles")
		
		.then()
			.statusCode(200)
			.body("[0]fileName", equalTo("Test1.txt"))
			.body("[1]fileName", equalTo("Test1.txt"))
			.log().all();
	}
	
	@Test
	public void multipleFileUpload_2() {    //wont work for all kind of API
		
		File myfile1 = new File("C:\\Users\\gottimukkula.ranjith\\Downloads\\text1.txt");
		File myfile2 = new File("C:\\Users\\gottimukkula.ranjith\\Downloads\\text2.txt");
		
		File filearr[] = {myfile1, myfile2};
		
		given()
			.multiPart("files", filearr)
			.contentType("multiPart/form-data")
		
		.when()
			.post("https://localhost:8080/uploadMultipleFiles")
		
		.then()
			.statusCode(200)
			.body("[0]fileName", equalTo("Test1.txt"))
			.body("[1]fileName", equalTo("Test1.txt"))
			.log().all();
	}
	
	@Test
	public void fileDownload() {
		
		given()
		
		.when()
			.get("https://localhost:8080/downloadFile/Test1.txt")
		
		.then()
			.statusCode(200)
			.log().body();
			
	}


}
