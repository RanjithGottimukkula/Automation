package AuthenticationsAuthorizations;

import org.testng.annotations.Test;

import com.github.javafaker.Faker;

public class FakerDataGenerator {
	
	@Test
	public void GenerateDummyData() {
		
		Faker fake = new Faker();
		
		String Name = fake.name().fullName();
		String Firstname = fake.name().firstName();
		String Lastname = fake.name().lastName();
		
		String Username = fake.name().username();
		String Password = fake.internet().password();
		String Email = fake.internet().safeEmailAddress();
		
		String PhoneNumber = fake.phoneNumber().cellPhone();
		
		System.out.println("Name:"+Name);
		System.out.println("Firstname:"+Firstname);
		System.out.println("Lastname:"+Lastname);
		System.out.println("Username:"+Username);
		System.out.println("Password:"+Password);
		System.out.println("Email:"+Email);
		System.out.println("PhoneNumber:"+PhoneNumber);
		
		
	}

}
