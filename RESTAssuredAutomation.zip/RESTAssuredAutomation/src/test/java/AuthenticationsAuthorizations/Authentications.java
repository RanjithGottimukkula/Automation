package AuthenticationsAuthorizations;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Authentications {
	
	@Test(priority=1)
	public void BasicAuth() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		given()
			.auth().basic("postman", "password")
		
		.when()
			.get("https://postman-echo.com/basic-auth")
		
		.then()
			.statusCode(200)
			.body("authenticated", equalTo(true))
			.log().all();
		
	}
	
	@Test(priority=2)
	public void Digest() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		given()
			.auth().digest("postman", "password")
		
		.when()
			.get("https://postman-echo.com/basic-auth")
		
		.then()
			.statusCode(200)
			.body("authenticated", equalTo(true))
			.log().all();
		
	}
	
	@Test(priority=3)
	public void Preemptive() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		given()
			.auth().preemptive().basic("postman", "password")
		
		.when()
			.get("https://postman-echo.com/basic-auth")
		
		.then()
			.statusCode(200)
			.body("authenticated", equalTo(true))
			.log().all();
		
	}
	
	@Test(priority=4)
	public void BearerToken() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		String BearerToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzM4MzEwNjA0LCJpYXQiOjE3MzgzMDcwMDQsImp0aSI6ImNkYjY2NTI4MjdjMzQ3Yzc5ZGZmM2Q2N2Y1MmVlYjFmIiwidXNlcl9pZCI6NH0.QFRvmgETHNsjo0eZ1rTfHNb6ZvJ0mOEymrENmUbspKk";
		
		given()
			.headers("Authorization", "Bearer "+BearerToken)
		
		.when()
			.get("http://api.github.com/user/repos")
		
		.then()
			.statusCode(200)
			.log().all();

	}
	
	@Test(priority=5)
	public void OAuth_1() {
				
		given()
			.auth().oauth("consumerKey", "consumerSecret", "accessToken", "tokenSecrate")
		
		.when()
			.get("url")
		
		.then()
			.statusCode(200)
			.log().all();

	}
	
	@Test(priority=6)
	public void OAuth_2() {
				
		given()
			.auth().oauth2("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9")
		
		.when()
			.get("url")
		
		.then()
			.statusCode(200)
			.log().all();

	}
	
	@Test(priority=7)
	public void APIkey() {
		
		//Method 1
		/*given()
			.queryParam("appid", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9") //appid is API key
		
		.when()
			.get("http://api.openweathermap.org/data/2.5/forecast/daily?q=Delhi&units=metric&cnt=7")
		
		.then()
			.statusCode(200)
			.log().all();*/
		
		//Method 2
		
		given()
			.queryParam("appid", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9")
			
			.pathParam("mypath", "data/2.5/forecast/daily")
			.queryParam("q", "Delhi")
			.queryParam("units", "metric")
			.queryParam("cnt", "7")
		
		.when()
			.get("http://api.openweathermap.org/{mypath}")
		
		.then()
			.statusCode(200)
			.log().all();
		

	}

}
