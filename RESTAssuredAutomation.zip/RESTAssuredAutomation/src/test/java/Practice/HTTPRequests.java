package Practice;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import org.testng.annotations.Test;
import io.restassured.RestAssured;

/*
 * Given - Prerequisites
 * When - All requests
 * Then - All validations
 * And - some times we use and also this will be part of then.
 * 
 * Given()
 * 		content type, set cookies, add auth, add param, set headers info etc...
 * 
 * When()
 * 		get, post, put, delete
 * 
 * Then()
 * 		validate status code, extract response, extract headers cookies & response body...
 */
public class HTTPRequests {
	
	int id;
	
	@Test(priority=1)
	public void getUsers() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		given()
		
		.when()
			.get("https://reqres.in/api/users?page=2")
		
		.then()
			.statusCode(200)
			.body("page", equalTo(2))
			.log().all();
	}
	
	@Test(priority=2)
	public void createUser() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		HashMap<String, String> data = new HashMap<String, String>();
		data.put("name", "pavan");
		data.put("job", "trainer");
		
		id=given()
			.header("x-api-key", "reqres-free-v1")
			.contentType("application/json")
			.body(data)
		
		.when()
			.post("https://reqres.in/api/users")
			.jsonPath().getInt("id");
		
		//.then()
		//	.statusCode(200)
		//	.body("page", equalTo(2))
		//	.log().all();
	}
	
	@Test(priority=3, dependsOnMethods= {"createUser"})
	public void updateUser() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		HashMap<String, String> data = new HashMap<String, String>();
		data.put("name", "rajesh");
		data.put("job", "software");
		
		given()
			.header("x-api-key", "reqres-free-v1")
			.contentType("application/json")
			.body(data)
		
		.when()
			.put("https://reqres.in/api/users/"+id)
		
		.then()
			.statusCode(200)
			.log().all();
	}
	
	@Test(priority=4)
	public void deleteUser() {
		
		given()
			.header("x-api-key", "reqres-free-v1")
		
		.when()
			.delete("https://reqres.in/api/users/"+id)
		
		.then()
			.statusCode(204)
			.log().all();
	}
	
	//@Test
	public void loginpost() {
		
		HashMap<String, String> data = new HashMap<String, String>();
		data.put("username", "admin");
		data.put("password", "!0PEX@123");
		data.put("client_id", "pexminerapi");
		data.put("client_secret", "b0234e219c30652baeeb337a41e12c71ab52386060107f6880c4034987da760e");
		
		given()
			.contentType("application/json")
			.body(data)
		
		.when()
			.post("http://10.10.50.20:8005/api/token/")
		
		.then()
			.statusCode(200)
			.log().all();
	}

}
