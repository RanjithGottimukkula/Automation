package PostRequests;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

/*Different ways to create POST request body
1) using HashMap
2) using Org.json
3) using POJO (Plain Old Java Object)
4) using external json file
*/
public class DiffWaysToCreatePostRequestBody {
	
	//using HashMap
	//@Test
	public void usingHashMap() {
		
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("name", "scott");
		data.put("location", "hyderabad");
		data.put("phone", "1234567890");
		
		String courseArr[] = {"c", "c++"};
		data.put("courses", courseArr);
		
		given()
			.contentType("application/json")
			.body(data)
		
		.when()
			.post("http://localhost:3000/students")
		
		.then()
			.statusCode(200)
			.body("name", equalTo("scott"))
			.body("location", equalTo("hyderabad"))
			.body("phone", equalTo("1234567890"))
			.body("courses[0]", equalTo("c"))
			.body("courses[1]", equalTo("c++"))
			.header("Content-Type", "application/json; charset=utf-8")
			.log().all();
	}
	
	//using Org.json
	//@Test
	public void usingOrgjson(){
		
		RestAssured.useRelaxedHTTPSValidation();
		
		JSONObject data = new JSONObject();
		data.put("name", "pavan");
		data.put("job", "trainer");
		
		given()
			.header("x-api-key", "reqres-free-v1")
			.contentType("application/json")
			.body(data.toString())
		
		.when()
			.post("https://reqres.in/api/users")
		
		.then()
			.statusCode(201)
			.body("name", equalTo("pavan"))
			.body("job", equalTo("trainer"))
			.log().all();
	}
	
	//using POJO (Plain Old Java Object)
	//@Test
	public void usingPOJO() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		Pojo_PostRequest data = new Pojo_PostRequest();
		data.setName("manjunath");
		data.setJob("software");
		
		given()
			.header("x-api-key", "reqres-free-v1")
			.contentType("application/json")
			.body(data)
		
		.when()
			.post("https://reqres.in/api/users")
		
		.then()
			.statusCode(201)
			.header("Content-Type", "application/json; charset=utf-8")
			.body("name", equalTo("manjunath"))
			.body("job", equalTo("software"))
			.log().all();
	}
	
	//External json file
	@Test
	public void usingJSONFile() throws FileNotFoundException {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		File f = new File(".\\body.json");
		FileReader fr = new FileReader(f);
		JSONTokener jt = new JSONTokener(fr);
		JSONObject data = new JSONObject(jt);
		
		given()
			.header("x-api-key", "reqres-free-v1")
			.contentType("application/json")
			.body(data.toString())
		
		.when()
			.post("https://reqres.in/api/users")
		
		.then()
			.statusCode(201)
			.header("Content-Type", "application/json; charset=utf-8")
			.body("name", equalTo("morpheus"))
			.body("job", equalTo("leader"))
			.log().all();
	}

}
