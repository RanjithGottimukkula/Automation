package PathAndQueryParameters;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class log {
	
	@Test
	public void logAll() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		given()
		
		.when()
			.get("https://www.google.com/")
		
		.then()
			//.log().body()
			//.log().cookies()
			//.log().headers();
			.log().all();
	}

}
