package PathAndQueryParameters;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class PathAndQueryParameters {
	
	//https://reqres.in/api/users?page=2&id=5
	
	@Test
	public void PathAndQueryParameter() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		given()
			.pathParam("mypath", "users") //Path parameter
			.queryParam("page", 2)	  //Query parameter
			.queryParam("id", 5)		  //Query parameter
		
		.when()
			.get("https://reqres.in/api/{mypath}")
		
		.then()
			.statusCode(200)
			//.body("data.first_name", equalTo("Michael"))
			.log().all();
	}

}
