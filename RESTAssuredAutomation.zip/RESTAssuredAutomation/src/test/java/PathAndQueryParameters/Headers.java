package PathAndQueryParameters;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.response.Response;

public class Headers {
	
	//@Test(priority=1)
	public void Headers() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		given()
		
		.when()
			.get("https://www.google.com/")
			
		.then()
			.header("Content-Type", "text/html; charset=ISO-8859-1")
			.and()
			.header("Content-Encoding", "gzip")
			.and()
			.header("Server", "gws");
	}
	
	@Test(priority=2)
	public void getHeaders() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		Response res = given()
		
		.when()
			.get("https://www.google.com/");
		
		//Get single header info
		//String headervalue = res.getHeader("Content-Type");
		//System.out.println("Header value is"+"--"+headervalue);
		
		//Get all headers info
		io.restassured.http.Headers myheaders = res.getHeaders();
		
		for(Header hd : myheaders) {
			
			System.out.println(hd.getName()+"---"+hd.getValue());
			
		}
	}

}
