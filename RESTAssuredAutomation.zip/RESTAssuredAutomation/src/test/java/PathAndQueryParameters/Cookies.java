package PathAndQueryParameters;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Cookies {
	
	//@Test(priority=1)
	public void Cookies() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		given()
		
		.when()
			.get("https://www.google.com/")
		
		.then()
			.statusCode(200)
			.cookie("AEC", "AVh_V2gvMxSsyXsa6sYQ-9zSrYIriB6KPSjHBm5KGWjM-deoYK6fe-_xxCo; expires=Thu, 01-Jan-2026 06:05:46 GMT; path=/; domain=.google.com; Secure; HttpOnly; SameSite=lax")
			.log().all();
		
	}
	
	@Test(priority=2)
	public void getCookiesInfo() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		Response res = given()
		
		.when()
			.get("https://www.google.com/");
		
		//Get single cookie info
		//String cookie_value = res.getCookie("AEC");
		//System.out.println("Value of cookie is"+"--"+cookie_value);
		
		//Get all cookies info
		Map<String, String>cookie_values = res.getCookies();
		//System.out.println(cookie_values.keySet());
		
		for(String key : cookie_values.keySet()) {
			
			String cookie_value = res.cookie(key);
			System.out.println(key+"---"+cookie_value);
			
		}
		
	}

}
