package ParsingResponseBodyJSONObject;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class ParsingResponseBodyJSONObject {
	
	//@Test(priority=1)
	public void TestJSONResponse() {
		
		RestAssured.useRelaxedHTTPSValidation();
//		SoftAssert softAssert = new SoftAssert();
//		softAssert.assertAll();
		
		//Approach-1
		/*given()
			.contentType(ContentTpe.JSON)
		
		.when()
			.get("https://reqres.in/api/unknown")
		
		.then()
			.statusCode(200)
			.header("Content-Type", "application/json; charset=utf-8")
			.body("data[3].name", equalTo("aqua sky"));
			//.log().all();*/
		
		//Approach 2
		Response res = given()
			.contentType(ContentType.JSON)
		
		.when()
			.get("https://reqres.in/api/unknown");
		
		Assert.assertEquals(res.getStatusCode(), 200);
		Assert.assertEquals(res.header("Content-Type"), "application/json; charset=utf-8");
		
		String name = res.jsonPath().get("data[3].name").toString();
		Assert.assertEquals(name, "aqua sky");	
			
	}
	
	@Test(priority=2)
	public void TestJSONResponseBody() {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		Response res = 
		given()
			.contentType(ContentType.JSON)		
		
		.when()
			.get("https://reqres.in/api/unknown");
		
		//JSON Object class
		JSONObject jo = new JSONObject(res.asString()); //Converting response to JSON object type
		
		//Print all names of data
		/*for(int i=0; i<jo.getJSONArray("data").length(); i++) {
			
			String names = jo.getJSONArray("data").getJSONObject(i).get("name").toString();
			System.out.println(names);
		}*/
		
		//Search for name in data in JSON - Validation 1
		boolean status = false;
		for(int i=0; i<jo.getJSONArray("data").length(); i++) {
			
			String names = jo.getJSONArray("data").getJSONObject(i).get("name").toString();
			if(names.equals("true red")) {
				status = true;
				break;
			}
		}
		Assert.assertEquals(status, true);
		
		//Validate total years in data - Validation 2
		double totalyears=0;
		for(int i=0; i<jo.getJSONArray("data").length(); i++) {
			
			String years = jo.getJSONArray("data").getJSONObject(i).get("year").toString();
			totalyears = totalyears+Double.parseDouble(years);
		}
		System.out.println("Total years"+"-"+totalyears);
		Assert.assertEquals(totalyears, 12015.0);
		
	}

}
