package APIChaining;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.json.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

public class UpdateUser {
	
	@Test
	public void updateuser(ITestContext context) {
		
		Faker fake = new Faker();
		
		JSONObject data = new JSONObject();
		data.put("name", fake.name().fullName());
		data.put("gender", "male");
		data.put("email", fake.internet().emailAddress());
		data.put("status", "active");
		
		String BearerToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9";
		
		//int id = (Integer) context.getAttribute("user_id");
		int id = (Integer) context.getSuite().getAttribute("user_id");
		
		given()
			.headers("Authorization", "Bearer "+BearerToken)
			.contentType("application/json")
			.pathParam("id", id)
			.body(data.toString())
		
		.when()
			.put("https://reqres.in/api/users/{id}")
			
		.then()
			.statusCode(200)
			.log().all();
		
	}

}
