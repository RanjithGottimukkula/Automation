package APIChaining;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.ITestContext;
import org.testng.annotations.Test;

public class GetUser {
	
	@Test
	public void getuser(ITestContext context) {
		
		//int id = (Integer) context.getAttribute("user_id");
		int id = (Integer) context.getSuite().getAttribute("user_id");
		
		String BearerToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9";
		
		given()
			.headers("Authorization", "Bearer "+BearerToken)
			.pathParam("id", id)
		
		.when()
			.get("https://reqres.in/api/users")
		
		.then()
			.statusCode(200)
			.log().all();
		
	}

}
