package APIChaining;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.ITestContext;
import org.testng.annotations.Test;

public class DeleteUser {
	
	@Test
	public void deleteuser(ITestContext context) {
		
		String BearerToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9";
		
		//int id = (Integer) context.getAttribute("user_id");
		int id = (Integer) context.getSuite().getAttribute("user_id");
		
		given()
			.headers("Authorization", "Bearer "+BearerToken)
			.pathParam("id", id)
		
		.when()
			.delete("https://reqres.in/api/users/{id}")
		
		.then()
			.statusCode(204)
			.log().all();
		
	}

}
