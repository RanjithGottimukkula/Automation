package APIChaining;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.json.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import io.restassured.RestAssured;

public class CreateUser {
	
	@Test
	public void Create(ITestContext context) {
		
		Faker fake = new Faker();
		
		JSONObject data = new JSONObject();
		data.put("name", fake.name().fullName());
		data.put("gender", "male");
		data.put("email", fake.internet().emailAddress());
		data.put("status", "inactive");
		
		String BearerToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9";
		
		int id = given()
					.headers("Authorization", "Bearer "+BearerToken)
					.contentType("application/json")
					.body(data.toString())
		
		.when()
			.post("https://reqres.in/api/users")
			.jsonPath().getInt("id");
		
		System.out.println("Generated ID:"+id);
		
		//context.setAttribute("user_id", id);
		context.getSuite().setAttribute("user_id", id);
		
	}

}
