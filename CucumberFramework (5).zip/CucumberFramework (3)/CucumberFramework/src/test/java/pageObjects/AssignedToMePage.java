package pageObjects;

import org.openqa.selenium.By;

public class AssignedToMePage {
	
	public static final By assignedtome=By.xpath("//a[text()='Assigned To Me']");
	public static final By bom_risk_toggle_button=By.xpath("//input[@ng-model='c.isSecTable2']/following-sibling::span");
	public static final By bom_risk_search_button=By.xpath("//input[@placeholder='Search']");
	public static final By filter=By.xpath("//*[@id='jsListView']/div[2]/div/div[1]/div[2]/button[1]");
	public static final By bulkupdate=By.xpath("//*[@id='jsListView']/div[2]/div/div[1]/div[2]/button[2]");
	public static final By state=By.xpath("//label[text()='State']/..");
	public static final By change_due_dt=By.xpath("//a[text()='Change Due Date']");
    public static final By change_state=By.xpath("//a[text()='Change State']");
	public static final By change_assigned_to=By.xpath("//a[text()='Change Assigned To']");
	public static final By bulk_update_chklall=By.xpath("//*[@id=\"jsListView\"]/div[2]/div/div[4]/table/thead//input");
	public static final By columnwise_search_button=By.xpath("//th/i[@class='fa fa-search']");
	public static final By columnwise_search_inputbox=By.xpath("//td/input[@placeholder='Search']");
	public static final By select_bom_checkbox=By.xpath("//*[@id=\"jsListView\"]/div[2]/div/div/div[4]/table/thead//input");
	public static final By Bulk_update=By.xpath("//*[@id=\"jsListView\"]/div[2]/div/div[1]/div[3]/button[2]");
	
	public static String BOM_checkbox;
	public static void select_bom_checkbox(String Cat_Name,String BOMName) {
		
		BOM_checkbox="//*[@id='jsListView']/div[2]/div/div[4]/table/tbody//td[@title='"+Cat_Name+"']/..//td[@title='"+BOMName+"']/..//input";
    
	}
}
