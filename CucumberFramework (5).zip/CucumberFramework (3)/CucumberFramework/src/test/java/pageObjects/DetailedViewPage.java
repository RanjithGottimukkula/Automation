package pageObjects;

import org.openqa.selenium.By;

public class DetailedViewPage {

	public static String projectRelease;
	public static String addedBomOptionsButton,addRiskToBOM,addDependencyToBOM,total_BOM_options,view_Bom;
	public static String workStream,workStreamAddRisk,workStreamButton,workStreamAddBom,viewdoc,add_delete_doc,
	workStream_green,workStream_yellow,workStream_red,total_WS_options,allworkStreamoptions,allworkStream,allworkStreamButton;
	public static String product,productAddRisk,productButton,productAddBom,total_product_options;
	public static String view_editBom,copy_cloneBom;
	public static String workStream_overall_status;

	public static final By btnGoToMarket =By.xpath("//button[text()='GTM']");
	public static final By deliverables_overview = By.xpath("//*[contains(text(),'Deliverables Overview')]");
	public static final By workstream_list=By.xpath("//select[@id='moduleSelect']");

	public static final By BOM_short_desc=By.xpath("//textarea[@id='BomShortDescription']");
	public static final By BOM_desc=By.xpath("//textarea[@id='BomDescription' and @ng-model='c.Desc']");
	public static final By BOM_category=By.xpath("//select[@ng-model='c.newbomcat_value']");
	public static final By BOM_partner=By.xpath("//select[@ng-model='c.newpartner_value']");
	public static final By BOM_type=By.xpath("//select[@ng-model='c.newbomtype_value']");
	public static final By BOM_state=By.xpath("//select[@ng-model='c.newstate_value']");
	public static final By BOM_due_date=By.xpath("//input[@id='sp_formfield_' and @ng-model='formattedDate']");
	public static final By select_checkbox=By.xpath("//*[@id=\"jsListView\"]/div[2]/div/div/div[4]/table/thead//input");
	public static final By Bulk_edit=By.xpath("(//*[@id='jsListView']/div[2]/div/div[1]/div[3]/button[2]"); //*[@id='jsListView']/div[2]/div/div[1]/div[3]/button[2]  
	//*[@id='jsListView']/div[2]/div/div/div[1]/div[3]/button)[2]
	public static final By clone_BOM_short_desc=By.xpath("//label[@for='BomDescription']/../input");
	public static final By clone_BOM_name=By.xpath("//textarea[@id='BomShortDescription']");
	public static final By clone_BOM_desc=By.xpath("//textarea[@id='BomDescription' and @ng-model='c.newdesc_value']");	
	public static final By add_document_to_BOM=By.xpath("//button[@ng-click='c.addLinkBOM()']");	
	public static final By document_name_BOM=By.xpath("//input[@ng-model='c.data.u_name']");
	public static final By document_link_BOM=By.xpath("//input[@ng-model='c.data.u_link']");
	public static final By add=By.xpath("//button[@id='add_link']");
	public static String remove_document_name,remove_BOM_document_name;

	public static final By cloneBOM_next=By.xpath("//button[@ng-click='cloneBOM()']");
	public static void set_BOMdocument(String name){
		remove_BOM_document_name="//a[text()='"+name+"']/following-sibling::button";
	}
	
	public static String BOM_checkbox;
    public static void select_checkbox(String BOMName) {

        BOM_checkbox="//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[@title='"+BOMName+"']/..//td[1]";
    }

	public static void set_document(String name){
		remove_document_name="//h4[text()='"+name+"']/../../button";
	}
	public static final By remove_doc_confirmation=By.xpath("//h4[text()='Are you sure you want to remove the document link?']");
	public static final By yes=By.xpath("//button[@class='btn btn-success']");
	public static String remove_dependency_name;

	public static void set_dependency(String name){
		remove_dependency_name="//td[text()='"+name+"']/preceding::span[@role='button']";
	}

	public static final By remove_dependency_confirmation=By.xpath("//h4[text()='Are you sure you want to remove the dependency?']");
	public static final By ok_button=By.xpath("//button[text()='OK']");
	public static final By add_button=By.xpath("//button[@id='insert_btn']");
	public static final By loading_dots=By.xpath("//div[@class='header-loader']");
	public static final By added_message=By.xpath("//div[@id='modalrecord']"); 
	public static final By close_add_document_message=By.xpath("//h1[contains(text(),'Add Document')]/..//button");
	public static final By close_view_edit_BOM_message=By.xpath("//div[contains(text(),'View/Edit BOM')]/..//img");//div[contains(text(),'View/Edit BOM')]/../button
	public static final By Risk_impact=By.xpath("//select[@ng-model='c.impact']");
	public static final By Risk_status=By.xpath("//select[@ng-model='c.risk_status']");
	public static final By mitigation_plan=By.xpath("//textarea[@ng-model='c.newmitigation_value']");
	public static final By add_document=By.xpath("//button[@ng-click='c.addlink()']");
	public static final By document_name=By.xpath("//input[@id='LinkName']");
	public static final By document_link=By.xpath("//input[@id='LinkURL']");

	public static final By editrisk_BOM_shortdescription=By.xpath("//input[@ng-model='c.newshdesc_value']");
	public static final By editrisk_BOM_description=By.xpath("//textarea[@id='BomDescription' and @ng-model='c.newdesc_value']");
	public static final By editrisk_BOM_impactstatus=By.xpath("//select[@ng-model='c.newimpact_value']");
	public static void setRelease(String release) {
		projectRelease="//*[text()='"+release+"']";
	}

	public static void setBOM(String value){
		addedBomOptionsButton="//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[@title='"+value+"']/..//button";
		addRiskToBOM="//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[@title='"+value+"']/..//button/..//a[text()='Add Risk']";
		addDependencyToBOM="//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[@title='"+value+"']/..//button/..//a[text()='Add a Dependency']";
		view_editBom="//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[@title='"+value+"']/..//button/..//a[text()='View/Edit BOM']";
		copy_cloneBom="//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[@title='"+value+"']/..//button/..//a[text()='Copy/Clone BOM']";
		total_BOM_options="(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[@title='"+value+"']/..//button/..//a)";
		view_Bom="//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[@title='"+value+"']/..//button/..//a[text()='View BOM']";
	}
	public static String view_editRiskOptionsButton,view_editRisk,total_risk_options,view_risk;
	public static void setBOM_Risk(String BOM, String Risk) {
		view_editRiskOptionsButton="//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button";
		view_editRisk="//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button/..//a[text()='View/Edit Risk']";
		total_risk_options="(//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button/..//a)";
		view_risk="//*[@id='jsListView']/div[3]/div/div/div[4]/table/tbody//td[@title='"+BOM+"']/..//td[@title='"+Risk+"']/..//button/..//a[text()='View Risk']";
	}
	public static void setWorkstream(String workstream_value) {
		allworkStream="//h5[contains(text(),'"+workstream_value+"')]/..";
		allworkStreamButton="//h5[contains(text(),'"+workstream_value+"')]/..//button";
		allworkStreamoptions="(//h5[contains(text(),'"+workstream_value+"')]/..//button/..//a)";
		workStream="(//h5[contains(text(),'"+workstream_value+"')]/../..)[1]";
		workStreamButton="(//h5[contains(text(),'"+workstream_value+"')]/../..//button)[1]";
		workStreamAddBom="//h5[contains(text(),'"+workstream_value+"')]/../..//button/..//a[text()='Add BOM']";
		workStreamAddRisk="//h5[contains(text(),'"+workstream_value+"')]/../..//button/..//a[text()='Add Risk']";
		workStream_overall_status="//h5[contains(text(),'"+workstream_value+"')]/..//p";
		viewdoc="//h5[text()='"+workstream_value+"']/../..//button/..//a[contains(text(),'View')]";
		add_delete_doc="//h5[text()='"+workstream_value+"']/../..//button/..//a[contains(text(),'Doc')]";
		workStream_green="(//h5[text()='"+workstream_value+"']/../..)[1]//div[@class='progress-bar bg-green']";
		workStream_yellow="(//h5[text()='"+workstream_value+"']/../..)[1]//div[@class='progress-bar bg-yellow']";
		workStream_red="(//h5[text()='"+workstream_value+"']/../..)[1]//div[@class='progress-bar bg-red']";
		total_WS_options="(//h5[text()='"+workstream_value+"']/../..//ul/li/a)";
	}
	public static void setProduct(String Product) {
		product="(//h5[text()='"+Product+"']/../..)[1]";
		productButton="(//h5[text()='"+Product+"']/../..//button)[1]";
		productAddBom="//h5[text()='"+Product+"']/../..//button/..//a[text()='Add BOM']";
		productAddRisk="//h5[text()='"+Product+"']/../..//button/..//a[text()='Add Risk']";
		total_product_options="(//h5[text()='"+Product+"']/../..//ul/li/a)";
	}
	public static final By all_workstream=By.xpath("//h5[contains(text(),'All Workstreams')]");
	public static final By all_products=By.xpath("//h5[contains(text(),'All Products')]");
	public static final By detailed_view=By.xpath("//a[@id='ITSMDetailedViewTab']");
	public static final By green_count=By.xpath("(//span[@class='countText' and text()='Green']/../p)[1]");
	public static final By yellow_count=By.xpath("(//span[@class='countText' and text()='Yellow']/../p)[1]");
	public static final By red_count=By.xpath("(//span[@class='countText' and text()='Red']/../p)[1]");
	public static final By filter=By.xpath("//button[@class='btn-link' and @data-target='#tableFilter']");
	public static final By notrequired_filter=By.xpath("(//*[@id='StateTab']/label)[4]/input");
	public static final By apply=By.xpath("(//button[text()='Apply'])[1]");

	public static final By dependent_BOM_prod_family_dropdown=By.xpath("(//span[text()='Dependent BOM Product Family']/../../following-sibling::div//a)[1]");
	public static final By dependent_BOM_prod_family_input=By.xpath("//input[@id='s2id_autogen6_search']");
	public static String dependent_BOM_value;
	public static final By dependent_BOM_workstream_dropdown=By.xpath("(//span[text()='Dependent BOM Workstream']/../../following-sibling::div//a)[1]");
	public static final By dependent_BOM_workstream_input=By.xpath("//input[@id='s2id_autogen8_search']");
	public static final By dependent_BOM_dropdown=By.xpath("//span[text()='Dependent BOM']/../../following-sibling::div//a");
	public static final By dependent_BOM_input=By.xpath("//input[@id='s2id_autogen10_search']");

	public static void setDependent_BOM_Value(String value) {
		dependent_BOM_value="//div[text()='"+value+"']";	
	}

	public static final By bom_risk_toggle_button=By.xpath("//input[@ng-change='c.updateView()']/following-sibling::span");

	public static final By workstream_dropdown=By.xpath("//select[@id='moduleSelect']");
	public static final By filterIcon=By.xpath("//button[@class='btn-link' and @data-target='#tableFilter']");
	public static final By filterComplete = By.xpath("(//*[@id='StateTab']/label)[1]/input");
	public static final By filterOpen = By.xpath("(//*[@id='StateTab']/label)[2]/input");
	public static final By filterWorkInProgress = By.xpath("(//*[@id='StateTab']/label)[3]/input");
	public static final By filterNotRequired=By.xpath("(//*[@id='StateTab']/label)[4]/input");
	public static final By BOM_current_date = By.xpath("");

	public static final By selectall=By.xpath("(//input[@ng-change='c.changeTableCheckBox()'])[1]");
	public static final By risk_selectall=By.xpath("(//input[@ng-change='c.changeTableCheckBox()'])[2]");
	public static final By search=By.xpath("(//th/i[@class='fa fa-search ng-scope'])[1]");
	public static final By risk_search=By.xpath("(//th/i[@class='fa fa-search ng-scope'])[2]");
	public static String search_input="//td/input[@placeholder='Search']";
	public static final By bulk_edit=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[1]/div[3]/button)[2]");
	public static  String filer_options="(//li[@ng-if='fltHeader.isFilter']//span/following-sibling::label)";
	public static String breadcrumb="(//button[contains(text(),'x')]/..)";
	public static final By filterapply=By.xpath("(//button[contains(text(),'Apply')])[1]");
}