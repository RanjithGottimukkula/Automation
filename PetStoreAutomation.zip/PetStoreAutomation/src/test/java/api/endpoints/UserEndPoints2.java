package api.endpoints;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.ResourceBundle;

import api.payload.User;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;


//Created for perform Create, Read, Update, Delete request the user API 

public class UserEndPoints2 {
	
	
	//Method created for getting URL's from property files
	public static ResourceBundle getURL() {
		
		ResourceBundle routes = ResourceBundle.getBundle("routes"); //Load properties file
		return routes;
	}
	
	public static Response createuser(User payload) {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		String post_url = getURL().getString("post_url");
		
		Response res = given()
			.contentType(ContentType.JSON)
			.accept(ContentType.JSON)
			.body(payload)
			
		.when()
			.post(post_url);
		
		return res;
	}
	
	public static Response readuser(String userName) {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		String get_url = getURL().getString("get_url");
		
		Response res = given()
			.pathParam("username", userName)
		
		.when()
			.get(get_url);
		
		return res;
	}
	
	public static Response updateuser(String userName, User payload) {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		String update_url = getURL().getString("update_url");
		
		Response res = given()
			.contentType(ContentType.JSON)
			.accept(ContentType.JSON)
			.pathParam("username", userName)
			.body(payload)
			
		.when()
			.put(update_url);
		
		return res;
	}
	
	public static Response deleteuser(String userName) {
		
		RestAssured.useRelaxedHTTPSValidation();
		
		String delete_url = getURL().getString("delete_url");
		
		Response res = given()
			.pathParam("username", userName)
			
		.when()
			.delete(delete_url);
		
		return res;
	}

}
