package api.test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import api.endpoints.UserEndPoints;
import api.endpoints.UserEndPoints2;
import api.payload.User;
import io.restassured.response.Response;

public class UserTests2 {

	Faker fake;
	User payload;
	Logger logger;

	@BeforeClass
	public void setup() {

		fake = new Faker();
		payload = new User();

		payload.setId(fake.idNumber().hashCode());
		payload.setUsername(fake.name().username());
		payload.setFirstName(fake.name().firstName());
		payload.setLastName(fake.name().lastName());
		payload.setEmail(fake.internet().safeEmailAddress());
		payload.setPassword(fake.internet().password(5, 10));
		payload.setPhone(fake.phoneNumber().cellPhone());

		// logs
		logger = LogManager.getLogger(this.getClass());

	}

	@Test(priority = 1)
	public void postUser() {

		logger.info("***** Creating user *****");
		Response res = UserEndPoints2.createuser(payload);
		res.then().log().all();

		Assert.assertEquals(res.getStatusCode(), 200);

		logger.info("***** User is created *****");
	}

	@Test(priority = 2)
	public void getUser() {

		logger.info("***** Reading user info *****");
		Response res = UserEndPoints2.readuser(this.payload.getUsername());
		res.then().log().all();

		Assert.assertEquals(res.getStatusCode(), 200);

		logger.info("***** User info is displayed *****");
	}

	@Test(priority = 3)
	public void updateUser() {

		logger.info("***** Updating user *****");

		// Update data using payload
		payload.setFirstName(fake.name().firstName());
		payload.setLastName(fake.name().lastName());
		payload.setEmail(fake.internet().safeEmailAddress());

		Response res = UserEndPoints2.updateuser(this.payload.getUsername(), payload);
		res.then().log().body();

		Assert.assertEquals(res.getStatusCode(), 200);

		logger.info("***** User updated *****");
		// Check data after update
		Response ResponseAfterUpdate = UserEndPoints2.readuser(this.payload.getUsername());
		Assert.assertEquals(ResponseAfterUpdate.getStatusCode(), 200);

	}

	@Test(priority = 4)
	public void deleteUser() {

		logger.info("***** Deleting user *****");
		Response re = UserEndPoints2.deleteuser(this.payload.getUsername());
		Assert.assertEquals(re.getStatusCode(), 200);

		logger.info("***** User deleted *****");
	}

}
