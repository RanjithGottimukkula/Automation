package api.test;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import api.endpoints.UserEndPoints;
import api.payload.User;
import api.utilities.DataProviders;
import io.restassured.response.Response;

public class DataDrivenTests {

	@Test(priority = 1, dataProvider = "Data", dataProviderClass = DataProviders.class)
	public void postUsers(String userID, String username, String fname, String lname, String useremail, String password,
			String phone) {

		User payload = new User();

		payload.setId(Integer.parseInt(userID));
		payload.setUsername(username);
		payload.setFirstName(fname);
		payload.setLastName(lname);
		payload.setEmail(useremail);
		payload.setPassword(password);
		payload.setPhone(phone);

		Response res = UserEndPoints.createuser(payload);
		res.then().log().all();

		Assert.assertEquals(res.getStatusCode(), 200);

	}

	@Test(priority = 2, dataProvider = "UserNames", dataProviderClass = DataProviders.class)
	public void deleteUsers(String username) {

		Response response = UserEndPoints.deleteuser(username);
		Assert.assertEquals(response.getStatusCode(), 200);

	}

}
