package api.utilities;

import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class DataProviders {

	@DataProvider(name = "Data")
	public String[][] getAllData() throws IOException {

		String path = System.getProperty("user.dir") + "//testData//Userdata.xlsx";
		XLUtility x1 = new XLUtility(path);

		int rowCount = x1.getRowCount("Sheet1");
		int colCount = x1.getCellCount("Sheet1", 1);

		String[][] apidata = new String[rowCount][colCount];

		for (int i=1; i<=rowCount; i++) {
			// Row row = sheet.getRow(i);
			for (int j=0; j<colCount; j++) {
				// Cell cell = row.getCell(j);
				apidata[i-1][j] = x1.getCellData("Sheet1", i, j);
			}
		}

		// workbook.close();
		// fis.close();
		return apidata;
	}

	@DataProvider(name = "UserNames")
	public String[] getUserNames() throws IOException {

		String path = System.getProperty("user.dir") + "//testData//Userdata.xlsx";
		XLUtility x1 = new XLUtility(path);

		int rowCount = x1.getRowCount("Sheet1");
		String[] apidata = new String[rowCount];

		for (int i=1; i<=rowCount; i++) {

			apidata[i-1] = x1.getCellData("Sheet1", i, 1);
		}

		// workbook.close();
		// fis.close();
		return apidata;
	}
}
