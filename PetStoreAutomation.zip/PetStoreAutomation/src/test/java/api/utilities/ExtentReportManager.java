package api.utilities;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportManager implements ITestListener {

	public ExtentSparkReporter sparkReporter;  //UI
	public ExtentReports extent; // To specify common information
	// private static ThreadLocal<ExtentTest> test = new ThreadLocal<ExtentTest>();
	public ExtentTest test; // Creating entries of pass, fail

	String repName;

	public void onStart(ITestContext context) {
		// ExtentSparkReporter sparkReporter = new
		// ExtentSparkReporter("test-output/ExtentReport.html");

		String timestamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.SS").format(new Date()); // time stamp
		repName = "Test-Report-" + timestamp + ".html";

		sparkReporter = new ExtentSparkReporter(".\\reports\\" + repName); // Specify location of the report

		sparkReporter.config().setDocumentTitle("Test Results"); // Title of report
		sparkReporter.config().setReportName("Automation Test Report"); // Name of the report
		sparkReporter.config().setTheme(Theme.STANDARD);

		extent = new ExtentReports();
		extent.attachReporter(sparkReporter);
		extent.setSystemInfo("Application", "Pet store users api");
		extent.setSystemInfo("Operating System", System.getProperty("os.name"));
		extent.setSystemInfo("User Name", System.getProperty("user.name"));
		extent.setSystemInfo("Environment", "QA");
		extent.setSystemInfo("Tester", "Ranjith");
	}

	/*
	 * public void onTestStart(ITestResult result) { ExtentTest extentTest =
	 * extent.createTest(result.getMethod().getMethodName()); test.set(extentTest);
	 * }
	 */

	public void onTestSuccess(ITestResult result) {
		test = extent.createTest(result.getName());
		test.assignCategory(result.getMethod().getGroups());
		test.createNode(result.getName());
		test.log(Status.PASS, "Test Passed");
	}

	public void onTestFailure(ITestResult result) {
		test = extent.createTest(result.getName());
		test.createNode(result.getName());
		test.assignCategory(result.getMethod().getGroups());
		test.log(Status.FAIL, "Test Failed");
		test.log(Status.FAIL, result.getThrowable().getMessage());
	}

	public void onTestSkipped(ITestResult result) {
		test = extent.createTest(result.getName());
		test.createNode(result.getName());
		test.assignCategory(result.getMethod().getGroups());
		test.log(Status.SKIP, "Test Skipped");
		test.log(Status.SKIP, result.getThrowable().getMessage());
	}

	public void onFinish(ITestContext context) {
		extent.flush();
	}

	// Optional: implement if needed
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
	}
}
