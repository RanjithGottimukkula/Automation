import java.util.HashMap;
import java.util.LinkedHashMap;

public class NumberOfWordInStringCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "this is That that is This get";
		s = s.toLowerCase();
		String[] ch = s.split(" ");

		HashMap<String, Integer> charcount = new LinkedHashMap<>();
		for (String c : ch) {
			charcount.put(c, charcount.getOrDefault(c, 0) + 1);
		}
		System.out.println("Values are:" + charcount);
		
		// remove repeating word
		StringBuilder sb = new StringBuilder();
		for(String c : ch) {
			if(charcount.get(c) == 1) {
				sb.append(c);
			}
		}
		System.out.println(sb);
		
	}
}
