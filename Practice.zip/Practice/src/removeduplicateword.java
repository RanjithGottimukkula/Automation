

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class removeduplicateword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "pavan kalyan pavan kalyan";
		String[] words = str.split(" ");
		
		HashSet<String> set = new LinkedHashSet<>();
		for(int i=0; i<words.length; i++) {
			set.add(words[i]);
		}
		System.out.println(set);
		
//		StringBuilder result = new StringBuilder();
//		for(String word : set) {
//			result.append(word).append(" ");
//		}
//		System.out.println(result);

	}
}
