import java.util.HashSet;
import java.util.LinkedHashSet;

public class removeduplicatevalues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1, 2, 3, 4, 5, 1, 2};

		HashSet<Integer> set = new LinkedHashSet<>();
		for (int i=0; i<arr.length; i++) {
			set.add(arr[i]);
		}
		System.out.println(set);
	}
}
