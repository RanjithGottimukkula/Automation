import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class removeduplicatecharacters {

	public static void main(String[] args) {

		String str = "pavan kalyan";
		char[] ch = str.toCharArray();

		HashSet<Character> set = new LinkedHashSet<>();
		for (int i=0; i<ch.length; i++) {
			set.add(ch[i]);
		}
		System.out.println(set);

		// Build the result string from the set
//		StringBuilder result = new StringBuilder();
//		for (Character c : set) {
//			result.append(c).append("");
//		}
//
//		// Print the resulting string with unique characters
//		System.out.println(result.toString());
	}
}
