
public class reversestringassame {
	
	public static void main(String[] args) {
		
		String str = "I am iopex";
		String[] s = str.split(" ");
		
		for(int i=s.length-1; i>=0; i--){
			System.out.print(s[i]+" ");
		}
		
	}
}
