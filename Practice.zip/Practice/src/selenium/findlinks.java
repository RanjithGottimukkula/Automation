package stepDefinitions;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class findlinks {

	public static void findLinks() {
		// Set up the Chrome driver and options
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\gottimukkula.ranjith\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		// Set Chrome options
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--headless");              // Headless mode
        options.addArguments("--disable-gpu");           // Disable GPU (optional, but recommended for headless)
        options.addArguments("--window-size=1920x1080"); // Set window size (optional)
		
		driver.get("https://demoqa.com/broken");
		driver.manage().window().maximize();
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		// Find all links on the page, For findElements() the preferred locators are: tagName and xpath
		List<WebElement> linkList = driver.findElements(By.tagName("a"));
		System.out.println("Total number of links: " + linkList.size());

		// Loop through each link and check its status
		for (WebElement web : linkList) {
			String url = web.getAttribute("href");
			String text = web.getText();
			System.out.println(url);
			System.out.println(text);
			verifyLinks(url);
		}
	}

	private static void verifyLinks(String link) {
		try {
			URL url = new URL(link);

			// Open a connection to the URL
			HttpURLConnection http = (HttpURLConnection) url.openConnection();
			http.setConnectTimeout(5000); // Set connection timeout
			http.connect();

			// Get the response code
			int responseCode = http.getResponseCode();

			if (responseCode == 200) {
				System.out.println(link + " is working" + responseCode);
			} else {
				System.out.println(link + " is broken" + responseCode);
			}

		} catch (IOException e) {
			System.out.println("Error while checking link: " + link + " - " + e.getMessage());
		}
	}

	public static void main(String[] args) {
		findLinks(); // Run the method to check broken links
	}

}
