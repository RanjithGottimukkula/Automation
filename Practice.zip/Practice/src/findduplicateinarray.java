
public class findduplicateinarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2};
		
		for(int i=0; i<arr.length; i++) {
			for(int j=i+1; j<arr.length; j++) {
				if(arr[i]==arr[j]) {
					System.out.println(arr[i]);
				}
			}
		}
		
	}
}

/*
int [] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 1, 2};
int count;

for(int i=0; i<arr.length; i++){
    count = 1;
    for(int j=i+1; j<arr.length; j++){
        if(arr[i]==arr[j]){
            count++;
            arr[j]=0;
        }
    }
    
    if(count>1 && arr[i]!=0){
        System.out.println(arr[i]+" "+count);
    }
}
*/