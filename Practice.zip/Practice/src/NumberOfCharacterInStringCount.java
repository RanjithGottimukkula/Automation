import java.util.HashMap;
import java.util.LinkedHashMap;

public class NumberOfCharacterInStringCount {

	public static void main(String[] args) {
		String s = "pawan kalyan";
		char[] ch = s.toCharArray();

		HashMap<Character, Integer> charcount = new LinkedHashMap<>();
		for (char c : ch) {
			if (c != ' ') { // Ignore spaces
				charcount.put(c, charcount.getOrDefault(c, 0) + 1); // Increment count
			}
		}
		System.out.println("Values are " + charcount);

		// remove repeating character
		StringBuilder sb = new StringBuilder();
		for (char c : ch) {
			if (c!=' ' && charcount.get(c) == 1) {
				sb.append(c);
			}
		}
		System.out.println(sb);

		// replace repeating character as 1
		for (char c : ch) {
			if (c!=' ' && charcount.get(c) > 1) {
				System.out.print(1);
			} else {
				System.out.print(c);
			}
		}
		
	}
}

/*Find the first non-repeating character.
	boolean found = false;
        for (char c : ch) {
            if (c != ' ' && charcount.get(c) == 1) {
                System.out.println("The first non-repeating character is: " + c);
                found = true;
                break; 
            }
        }
        
        if (found==false) {
            System.out.println("No unique character found.");
        }
*/
