
public class reversestring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Given array
        //int[] arr = {4, 5, 2, 6};
		String str = "Hello World";
		char[] arr = str.toCharArray();
		
		for (int i=arr.length-1; i>=0; i--) {
			System.out.print(arr[i]);
		}
	}
}
