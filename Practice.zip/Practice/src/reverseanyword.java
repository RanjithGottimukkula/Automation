
public class reverseanyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "ramagundam godavarikhani karimnagar";
		String[] ch = str.split(" ");
		
		for(int i=0; i<ch.length; i++) {
			String word = ch[i];
			
			if(i==1) {
				StringBuilder sb = new StringBuilder(word);
				word = sb.reverse().toString();
			}
			
			System.out.print(word+" ");
			
//			if(i>0) {
//				System.out.print(" ");
//			}
//			System.out.print(word);
		}

	}
}

