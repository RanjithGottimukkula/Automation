import java.util.Arrays;

public class arraysort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n[] = { 2, 4, 6, 8, 0, 1, 3, 5, 7, 9 };
		// System.out.println(Arrays.toString(a));

//		Arrays.sort(num);
//		System.out.println(Arrays.toString(num));
//		Arrays.sort(num, Collections.reverseOrder());
//		System.out.println(Arrays.toString(num));

		// Selection sort
		for (int i=0; i<n.length; i++) {
			for (int j=i+1; j<n.length; j++) {
				if (n[i] > n[j]) {
					int temp = n[i];
					n[i] = n[j];
					n[j] = temp;
				}
			}
		}

		// Printing the sorted array
		for (int i=0; i<n.length; i++) {
			System.out.print(n[i] + " ");
		}
	}
}

/* Bubble sort
for(int i=0; i<n.length; i++){
    for(int j=0; j<n.length-i-1; j++){
        if(n[j] < n[j+1]){
            int temp = n[j];
            n[j] = n[j+1];
            n[j+1] = temp;
        }
    }
}    
*/