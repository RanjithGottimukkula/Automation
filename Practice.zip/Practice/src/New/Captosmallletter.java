package New;

public class Captosmallletter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "softwa RE";
		char[] ch = str.toCharArray();
		
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<ch.length; i++) {
			if(Character.isUpperCase(ch[i])) {
				sb.append(Character.toLowerCase(ch[i]));
			}else if (Character.isLowerCase(ch[i])){
				sb.append(Character.toUpperCase(ch[i]));
			}else {
				sb.append(ch[i]); // non-letters unchanged
			}
		}
		System.out.println(sb);

	}
}
