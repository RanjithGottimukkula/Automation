package New;

public class Reversealternatewords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "This is a test string";
		String[] sp = str.split(" ");
		
		for(int i=0; i<sp.length; i++) {
			if(i%2==1) {
				char[] ch = sp[i].toCharArray();
				for(int j=ch.length-1; j>=0; j--) {
					System.out.print(ch[j]);
				}
			}else {
				System.out.print(sp[i]);
			}
			if(i>=0) {
				System.out.print(" ");
			}
		}
		
	}
}
