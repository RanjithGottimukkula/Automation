package New;

public class OddLeftEvenRight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		int[] rearrange = new int[num.length];
		int index = 0;

		// First pass: add odd numbers
		for (int i=0; i<num.length; i++) {
			if (num[i]%2 != 0) {
				rearrange[index++] = num[i];
			}
		}

		// Second pass: add even numbers
		for (int i=0; i<num.length; i++) {
			if (num[i]%2 == 0) {
				rearrange[index++] = num[i];
			}
		}

		// Print the rearranged array
		for (int i=0; i<rearrange.length; i++) {
			System.out.print(rearrange[i] + " ");
		}

	}
}
