package New;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Sorthashmapbyvalues {
	
	public static void main(String[] args) {

	HashMap<String, Integer> map = new HashMap<>();
	map.put("a",1);
	map.put("b",3);
	map.put("c",5);
	map.put("d",2);
	System.out.println(map);

	// Convert to list and sort by value
	ArrayList<Map.Entry<String, Integer>> list = new ArrayList<>(map.entrySet());

	// Bubble sort by values
	for(int i=0; i<list.size(); i++) {
		for (int j=0; j<list.size()-i-1; j++) {
			if (list.get(j).getValue() > list.get(j+1).getValue()) {
				// Swap entries
				Map.Entry<String, Integer> temp = list.get(j);
				list.set(j, list.get(j+1));
				list.set(j+1, temp);
			}
		}
	}

	// Print sorted entries
	for(Map.Entry<String, Integer> entry : list) {
		System.out.println(entry.getKey() + "-" + entry.getValue());
	}
	
	}
}

/*
// Convert to list and sort by value
   List<Map.Entry<String, Integer>> list = new ArrayList<>(map.entrySet());
   list.sort(Map.Entry.comparingByValue());

   // Print sorted entries
   for (Map.Entry<String, Integer> entry : list) {
         System.out.println(entry.getKey() + "-" + entry.getValue());
    }
*/

/*
// CHANGE IS HERE:
// 1. Get the Keys
// 2. Use .compareTo() > 0 to check if the first string comes after the second alphabetically
   if (list.get(j).getKey().compareTo(list.get(j+1).getKey()) > 0){
   }
*/

/* 
//Integer Keys (Numeric Sort)
TreeMap<Integer, String> map = new TreeMap<>();
map.put(10, "Ten");
map.put(1, "One");
map.put(2, "Two");

System.out.println(map); 
// Output: {1=One, 2=Two, 10=Ten}  <-- Correct Number Order

//String Keys (Alphabetical Sort)
TreeMap<String, Integer> map = new TreeMap<>();
map.put("b", 3);
map.put("a", 1);
map.put("d", 2);

System.out.println(map);
// Output: {a=1, b=3, d=2} <-- Correct Alphabetical Order


//The "String Number" Trap
//Be careful if you use Strings to hold numbers. Strings sort character by character, not by value.

TreeMap<String, String> map = new TreeMap<>();
map.put("10", "Ten");
map.put("2", "Two");

System.out.println(map);
// Output: {10=Ten, 2=Two} 
// WHY? Because alphabetically, the character '1' comes before '2'.
 
*/
