package New;

public class Swapalternatewords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "This is a test string java";
		String[] ch = str.split(" ");

		for (int i=0; i<ch.length; i++) {
			for (int j=0; j<ch.length; j++) {
				if (i%2==0 && j==i+1) {
					String temp = ch[i];
					ch[i] = ch[j];
					ch[j] = temp;
				}
			}
		}
		// System.out.println(String.join(" ",ch));

		for (int i=0; i<ch.length; i++) {
			System.out.print(ch[i] + " ");
		}

	}
}
