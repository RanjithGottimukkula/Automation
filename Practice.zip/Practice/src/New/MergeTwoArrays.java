package New;

import java.util.Arrays;

public class MergeTwoArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] n1 = {1,2,3,4,5};
		int[] n2 = {6,7,8,9,0};
		int[] n3 = new int[n1.length+n2.length];
		
		for(int i=0; i<n1.length; i++) {
			n3[i] = n1[i];
		}
		
		for(int i=0; i<n2.length; i++) {
			n3[n1.length+i] = n2[i];
		}
		
		for(int i=0; i<n3.length; i++) {
			System.out.print(n3[i]);
		}
		
//		System.out.println(Arrays.toString(n3));
//		Arrays.sort(n3);
//		System.out.println(Arrays.toString(n3));

	}

}
