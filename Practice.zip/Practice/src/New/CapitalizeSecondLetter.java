package New;

public class CapitalizeSecondLetter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "roses are beautiful";
		String[] words = str.split(" ");
		
		StringBuilder result = new StringBuilder();
		for (String word : words) {
			if (word.length() >= 2) {
				result.append(word.charAt(0)); // First letter as-is
				result.append(Character.toUpperCase(word.charAt(1))); // Second letter capitalized
				result.append(word.substring(2)); // Rest of the word
			} else {
				result.append(word); // If word has only one letter
			}
			result.append(" "); // Add space after each word
		}
		System.out.println(result);

	}
}
