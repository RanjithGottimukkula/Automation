package New;

public class Printvowels {

	public static void main(String[] args) {

		String str = "STR2AN1GE3R";
		str = str.toLowerCase();
		char[] ch = str.toCharArray();

		int v = 0, c = 0, n = 0;
		StringBuilder vowel = new StringBuilder();
		StringBuilder consonant = new StringBuilder();
		StringBuilder digit = new StringBuilder();

		for (int i=0; i<ch.length; i++) {
			if (Character.isDigit(ch[i])) {
				n++;
				digit.append(ch[i]);
			} else if (Character.isLetter(ch[i])) {
				if (ch[i] == 'a' || ch[i] == 'e' || ch[i] == 'i' || ch[i] == 'o' || ch[i] == 'u') {
					v++;
					vowel.append(ch[i]);
				} else {
					c++;
					consonant.append(ch[i]);
				}
			}
		}

		System.out.println(v + "=" + vowel);
		System.out.println(c + "=" + consonant);
		System.out.println(n + "=" + digit);

	}
}


/*

 String str = "java123";
        char[] ch = str.toCharArray();
        
        int v = 0, c = 0,n = 0;
        Set<Character> vowelSet = new LinkedHashSet<>();
        Set<Character> consonantSet = new LinkedHashSet<>();
        Set<Character> digitSet = new LinkedHashSet<>();

        for(int i=0; i<ch.length; i++){
            if(Character.isDigit(ch[i])){
                n++;
                digitSet.add(ch[i]);
            }else if(Character.isLetter(ch[i])){
                if(ch[i]=='a' || ch[i]=='e' || ch[i]=='i' || ch[i]=='o' || ch[i]=='u'){
                    v++;
                    vowelSet.add(ch[i]);
                }else{
                    c++;
                    consonantSet.add(ch[i]);
                }
            }
        }
        
        System.out.println(v+"="+vowelSet);
        System.out.println(c+"="+consonantSet);
        System.out.println(n+"="+digitSet);
 
*/
