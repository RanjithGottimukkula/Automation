package New;

public class Namesorting {

	public static void main(String[] args) {

		String str = "iopex";
		char[] ch = str.toCharArray();

		for (int i=0; i<ch.length-1; i++) {
			for (int j=0; j<ch.length-i-1; j++) {
				if (ch[j] < ch[j+1]) {
					char temp = ch[j];
					ch[j] = ch[j+1];
					ch[j+1] = temp;
				}
			}
		}

		for (int i=0; i<ch.length; i++) {
			System.out.print(ch[i]);
		}
	}
}


/*String str = "iopex";

        // Step 1: Convert string to a list of Character objects
        List<Character> chars = new ArrayList<>();
        for (char c : str.toCharArray()) {
            chars.add(c);
        }

        // Step 2: Sort the list in descending order
        Collections.sort(chars, Collections.reverseOrder());

        // Step 3: Print out the result
        System.out.print("Characters in descending order: ");
        for (char c : chars) {
            System.out.print(c);
        }
*/
