package New;

public class separatenumberandletter {

	public static void main(String[] arg) {

		String str = "test123";
		char[] ch = str.toCharArray();

		StringBuilder num = new StringBuilder();
		StringBuilder let = new StringBuilder();

		for (int i=0; i<ch.length; i++) {
			if (Character.isDigit(ch[i])) {
				num.append(ch[i]);
			} else if (Character.isLetter(ch[i])) {
				let.append(ch[i]);
			}
		}
		System.out.println("Letters:" + num);
		System.out.println("Digits:" + let);

	}
}
