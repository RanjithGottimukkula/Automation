package New;

public class MiddleNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] n = {1, 2, 3, 4, 5, 6, 7, 8};
		int len = n.length;
		
		if (len%2 == 0) {	//Even
			int k = len/2;
			System.out.println(n[k]+" "+n[k-1]);
//			int sum = n1[k]+n1[k-1];
//			System.out.println(sum/2);
//			System.out.println(sum);
//			System.out.println(k);

		} else {	//Odd
			int k = len/2;
			System.out.println(n[k]);
		}

	}

}
