package New;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class printvowelswithcount {

	public static void main(String[] args) {

		String s1 = "hunger";
		String s2 = "games";
		s1 = s1.toLowerCase();
		s2 = s2.toLowerCase();
		String merged = s1 + s2;
		char[] ch = merged.toCharArray();

		HashMap<Character, Integer> map = new LinkedHashMap<>();
		map.put('a', 0);
		map.put('e', 0);
		map.put('i', 0);
		map.put('o', 0);
		map.put('u', 0);

		for (char c : ch) {
			if (map.containsKey(c)) {
				map.put(c, map.getOrDefault(c, 0) + 1);
			}
		}
		System.out.println(map);
		
		// print only vowels whose count > 0
		for(Map.Entry<Character, Integer> entry : map.entrySet()) {
			if(entry.getValue() > 0) {
				System.out.println(entry.getKey()+"-"+entry.getValue());
			}
		}

//		System.out.println("Merged string: " + merged);
//        System.out.println("Vowel counts:");
//		System.out.println("a = " + map.get('a'));
//        System.out.println("e = " + map.get('e'));
//        System.out.println("i = " + map.get('i'));
//        System.out.println("o = " + map.get('o'));
//        System.out.println("u = " + map.get('u'));

	}

}
