package programs;

import java.util.ArrayList;

public class findsecondlargeststring {

	public static void main(String[] args) {
		String[] a = {"name", "kumar", "types", "prav"};
		int first = 0;
		int second = 0;

		// First, find the largest and second largest lengths
		for (String s : a) {
			if (s.length() > first) {
				second = first;
				first = s.length();
			} else if (s.length() > second && s.length() < first) {
				second = s.length();
			}
		}

		// Now, collect all strings with the second largest length
		ArrayList<String> secondLargestStrings = new ArrayList<>();
		for (String s : a) {
			if (s.length() == second) {
				secondLargestStrings.add(s);
			}
		}

		// Output the second largest strings
		System.out.println("Second largest strings are: " + secondLargestStrings);
		System.out.println("Second largest strings are: " + first);

	}
}

//--To find second smallest

//int first = Integer.MAX_VALUE;
//int second = Integer.MAX_VALUE;
//if (s.length() < first)
//else if (s.length() < second && s.length() > first)