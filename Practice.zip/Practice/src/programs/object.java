package programs;

import java.util.HashMap;

public class object {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Object, Object> hmap = new HashMap<>();
        hmap.put("K1", 23);
        hmap.put("K2", "Ranjith");
        hmap.put("K3", true);
        System.out.println(hmap);
	}
}
