package programs;

public class reversethelongestword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "I love Java Programming";
		String[] words = s.split(" ");
		String longWord = "";
		int length = 0;
		
		for(String word : words) {
			if (word.length() > length) {
				length = word.length();
				longWord = word;
			}
		}
		//System.out.println(longWord);
		//System.out.println(length);
		StringBuilder sb = new StringBuilder(longWord).reverse();
		//System.out.println(sb);
		String result = s.replace(longWord, sb);
		System.out.println(result);
	}
}
