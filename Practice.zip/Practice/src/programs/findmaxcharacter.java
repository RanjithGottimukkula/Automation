package programs;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class findmaxcharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "geeksforgeeks";
		char[] ch = str.toCharArray();
		int maxCount = 0;
		char maxChar = 0;

		HashMap<Character, Integer> map = new LinkedHashMap<>();
		for (char c : ch) {
			map.put(c, map.getOrDefault(c, 0) + 1);
			if (map.get(c) > maxCount) {
				maxCount = map.get(c);
				maxChar = c;
			}
		}
		System.out.println(map);
		System.out.println(maxCount);
		System.out.println(maxChar);
	}
}

/*
String str = "geeks for geeks";
String[] ch = str.split(" ");
int maxCount = 0;
String maxChar = null;

HashMap<String, Integer> map = new LinkedHashMap<>();
for (String c : ch) {
	map.put(c, map.getOrDefault(c, 0) + 1);
	if (map.get(c) > maxCount) {
		maxCount = map.get(c);
		maxChar = c;
	}
}
System.out.println(map);
System.out.println(maxCount);
System.out.println(maxChar);

*/