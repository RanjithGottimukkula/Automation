package programs;

public class numerictoalphabetic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "a1b2c3";
		char[] ch = s.toCharArray();

		for (int i=0; i<ch.length; i++) {
			if (Character.isAlphabetic(ch[i])) {
				System.out.print(ch[i]);
			} else {
				int v = Character.getNumericValue(ch[i]);
				for (int j=1; j<v; j++)
					System.out.print(ch[i-1]);
			}
		}
		
	}
}
