package programs;

public class printthreeinnextline {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 123456789;
		String str = String.valueOf(a);
		char[] ch = str.toCharArray();
		
		for(int i=0; i<ch.length; i++) {
			System.out.print(ch[i]);
			if((i+1)%3==0) {
				System.out.println();
			}
		}
		
	}
}
