package programs;

import java.util.ArrayList;

public class arraytolist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num = {1, 4, 5, 7, 8}; 
		
		ArrayList<Integer> list = new ArrayList<>();
		for(int i=0; i<num.length; i++) {
			list.add(num[i]);
		}
		System.out.println(list);
		
	}
}
