package programs;

public class movezeroelementtolast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num = {0, 2, 0, 4, 5, 6, 0, 8, 9};
		int n = num.length;
		int index = 0;
		
		//Move non-zero elements to the front
		for(int i=0; i<n; i++) {
			if(num[i] != 0) {
				num[index] = num[i];
				index++;
			}
		}
		
		//Fill the remaining positions with zeros
		while(index < n) {
			num[index] = 0;
			index++;
		}
		
		//Print the modified array
		for(int i=0; i<n; i++) {
			System.out.print(num[i]);
		}
	}
}
