package programs;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class findmincharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "geeksforgeeks";
        char[] ch = str.toCharArray();
        
        int minCount = Integer.MAX_VALUE;  //Initialize minCount to a very high value
        char minChar = 0;

        HashMap<Character, Integer> map = new LinkedHashMap<>();
        for (char c : ch) {
            map.put(c, map.getOrDefault(c, 0) + 1);
        }

        // Loop through the map to find the character with the minimum count
        for (char c : map.keySet()) {
            if (map.get(c) < minCount) {
                minCount = map.get(c);
                minChar = c;
            }
        }

        System.out.println(map);  // Prints the frequency map
        System.out.println("Min count: " + minCount);  // Prints the lowest count
        System.out.println("Min character: " + minChar);  // Prints the character with min count
	}
}
