package programs;

public class swapfirstlast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = {1,2,3,4,5,6,3,1,6};
		int l = a.length;
		
		int temp = a[l-1];
		a[l-1] = a[0];
		a[0] = temp;
		for(int b : a) {
			System.out.print(b);
		}
		
	}
}
