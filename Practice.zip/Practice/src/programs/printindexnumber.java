package programs;

import java.util.ArrayList;
import java.util.Scanner;

public class printindexnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num = {20, 30, 30, 15, 12, 40};
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number:");
		int n = sc.nextInt();

		ArrayList<Integer> list = new ArrayList<>();
		for (int i=0; i<=num.length-1; i++) {
			if (n==num[i]) {
				list.add(i);
			}
			// else{
			// System.out.println("Number is not present");
			// }
		}
		if (list.isEmpty()) {
			System.out.println("Element not found");
		} else {
			System.out.println(list);
		}

	}
}

/*import java.util.*;
class Main {
    public static void main(String[] args) {
        int a[] ={22,0,91,30,22,51,77};
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int num = sc.nextInt();
        
        boolean status = false;
        for(int i=0; i<a.length; i++){
            if(num ==a[i]) {
                System.out.println(i);
                status = true;
            }
        }
        if (status==false){
        System.out.println("Number not present in Array");
        }
    }
}*/
