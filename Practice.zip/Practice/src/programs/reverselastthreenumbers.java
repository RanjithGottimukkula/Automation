package programs;

public class reverselastthreenumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 1234567;
		String s = String.valueOf(a);
		char[] ch = s.toCharArray();

		StringBuilder sb = new StringBuilder();
		for(int i=4; i<ch.length; i++) {
			sb.append(ch[i]);
		}
		sb = sb.reverse();
		System.out.println(sb);
		
		StringBuilder sc = new StringBuilder();
		for(int i=0; i<4; i++) {
			sc.append(ch[i]);
		}
		
		System.out.println(sc.append(sb));
		
	}
}
