package programs;

public class alphabetictointeger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "abbccc";
		char[] ch = str.toCharArray();

		StringBuilder sb = new StringBuilder();
		int count = 1;
		for (int i=0; i<ch.length; i++) {
			if (i+1 < ch.length && ch[i]==ch[i+1]) {
				count++;
			} else {
				sb.append(ch[i]).append(count);
				count = 1;
			}
		}
		System.out.println(sb);
	}
}

/*
String str = "aabbbccbc";
char[] ch = str.toCharArray();

HashMap<Character, Integer> map = new LinkedHashMap<>();
for(char c : ch){
    map.put(c, map.getOrDefault(c, 0)+1);
}
System.out.println(map);

StringBuilder sb = new StringBuilder();
for(Map.Entry<Character, Integer> c : map.entrySet()){
    sb.append(c.getKey()).append(c.getValue());
}
System.out.println(sb);
*/