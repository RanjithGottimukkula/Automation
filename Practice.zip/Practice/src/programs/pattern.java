package programs;

public class pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1, 2, 3, 4, 5};

		for(int i=0; i<arr.length; i++) {
			for(int j=0; j<=i; j++) {
				System.out.print(arr[j]);
				// System.out.print("* ");
			}
			System.out.println();
		}
		
	}
}


/*Add this in between above two for loop
//Print spaces before stars
for(int k=0; k<arr.length-i-1; k++) {
	System.out.print(" ");
}
*/