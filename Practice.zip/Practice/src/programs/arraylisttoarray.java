package programs;

import java.util.ArrayList;

public class arraylisttoarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> list = new ArrayList<>();
		list.add("aa");
		list.add("bb");
		list.add("cc");
		//System.out.print(list);
		
		// Convert ArrayList to Array using toArray()
		String[] str = new String[list.size()];
		str = list.toArray(str);  // This line does the conversion
//		for(int i=0; i<list.size(); i++) {
//			str[i] = list.get(i);
//		}
		
		// Print the array elements
		for(int i=0; i<str.length; i++) {
			System.out.print(str[i]);
		}
	}
}

/*
  ArrayList<Integer> list = new ArrayList<>();
		list.add(11);
		list.add(12);
		list.add(13);
		System.out.println(list);
		
		int[] str = new int[list.size()];
		for(int i=0; i<list.size(); i++) {
			str[i] = list.get(i);
		}
		
		for(int i=0; i<str.length; i++){
		    System.out.println(str[i]);
		}

*/
