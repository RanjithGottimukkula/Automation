package programs;

public class findsecondlargestnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = {1, 15, 3, 5, 7, 9, 11};
		int first = 0;
		int second = 0;
		
		for (int i=0; i<a.length; i++) {
			if (a[i] > first)
				first = a[i];
		}

		for (int i=0; i<a.length; i++) {
			if (a[i] > second && a[i] != first)
				second = a[i];
		}
		
		System.out.println("Biggest number is " + first);
		System.out.println("Second largest number is " + second);
	}
}

//--To find second smallest

//int first = Integer.MAX_VALUE;
//int second = Integer.MAX_VALUE;
//if (a[i] < first)
//if (a[i] < second && a[i] != first)