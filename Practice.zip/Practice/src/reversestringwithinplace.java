
public class reversestringwithinplace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String value = "Test Automation";
		String[] val = value.split(" ");

		for(int i=0; i<val.length; i++) {
			char[] wor= val[i].toCharArray();
			for(int j=wor.length-1; j>=0; j--) {
				System.out.print(wor[j]);
				}
			System.out.print(" ");
		}
		
	}
}
 