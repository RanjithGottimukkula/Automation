public class palindromenumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r, sum=0, temp; // r=4, sum=4, n=45

		int n = 454;
		temp = n;

		while(n>0) {
			r=n%10; // 454%10 = 4 Remainder
			sum=(sum*10) + r; // (0*10)+4 = 4
			n=n/10; // 454/10 = 45 Quotient
		}
		if(temp==sum)
			System.out.println("Palindrome Number");
		else
			System.out.println("Not Palindrome Number");
		
	}
}

//sum = sum+(int)Math.pow(rem,3);[Armstrong]
//sum = sum+rem;//Sum of digits

//String str = "madams";
//char[] arr = str.toCharArray();
//String rev="";
//
//for (int i=arr.length-1; i>=0; i--) {
//	rev = rev+arr[i];
//}
////System.out.println(rev);
//
//if(str.equals(rev)){
//    System.out.println("Palindrome");
//}else{
//    System.out.println("Not palindrome");
//}
