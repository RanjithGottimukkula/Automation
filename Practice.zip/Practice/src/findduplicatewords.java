
public class findduplicatewords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Big black bug bit a big black dog on his big black nose";
		str = str.toLowerCase();
		String [] arr = str.split(" ");// {"Big", "black"}
		int count;

		for(int i=0; i<arr.length; i++) {
			count=1;
			for(int j=i+1; j<arr.length; j++) {
				if((arr[i]).equals(arr[j])) {
					count++;
					arr[j] = "0";
				}
			}
			if(count>1 && arr[i] != "0") {
				System.out.println(arr[i] + " " + count);
			}
		}
		
	}
}
