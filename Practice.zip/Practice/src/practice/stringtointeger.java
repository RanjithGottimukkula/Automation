package practice;

public class stringtointeger {
	public static void main(String[] args) {

		String str = "110A0B2C";
		// Extract the numeric part of the string (only digits)
		String numeric = str.replaceAll("[^0-9]", ""); // Regex to remove non-numeric characters
		int var = Integer.parseInt(numeric); //int var = Integer.valueOf(numeric);
		//System.out.println("Converted integer: " + numericPart);
		System.out.println("Converted integer: " + var);
		System.out.println("Converted integer: " + numeric);
	}
}
