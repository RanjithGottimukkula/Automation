package practice;

import java.util.HashSet;

public class missingnumber {
	 public static void main(String[] args) {
	        int[] num = {1, 3, 5, 7, 9, 12, 10, 1, 2}; // Example array where 4, 6, 8 and 11 are missing

	        // Find the minimum and maximum elements in the array
	        int minValue = Integer.MAX_VALUE;
	        int maxValue = Integer.MIN_VALUE;
	        
	        // Find the minimum and maximum values in the array
	        for (int n : num) {
	            if (n < minValue) {
	                minValue = n;
	            }
	            if (n > maxValue) {
	                maxValue = n;
	            }
	        }

	        // Store array elements in a HashSet for quick lookup
	        HashSet<Integer> set = new HashSet<>();
	        for (int i=0; i<num.length; i++) {
	            set.add(num[i]);
	        }

	        // Identify the missing numbers in the sequence
	        System.out.print("The missing numbers are: ");

	        // Iterate through the expected range from the minimum to the maximum
	        for (int i=minValue; i<=maxValue; i++) {
	            // Check if i is missing in the set
	            if (!set.contains(i)) {
	                System.out.print(i + " ");
	            }
	        }
	        
	    }
	}