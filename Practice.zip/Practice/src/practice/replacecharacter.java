package practice;

public class replacecharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Fat";
		String result = str.replace('F', 'R');
		System.out.println(result);
	}
}
