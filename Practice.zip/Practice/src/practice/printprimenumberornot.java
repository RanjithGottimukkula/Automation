package practice;

public class printprimenumberornot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 19;
		int count = 0;

		if (num>1) {
			for (int i=1; i<=num; i++) {
				if (num%i == 0) {
					count++;
				}
			}
			if (count==2) {
				System.out.println("Prime number");
			} else {
				System.out.println("Not prime number");
			}
		} else {
			System.out.println("Not prime number");
		}
		
	}
}

//Natural Number greater than 1
//Which has only 2 factors 1 and itself
