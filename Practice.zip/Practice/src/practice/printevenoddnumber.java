package practice;

public class printevenoddnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		
		System.out.println("Even numbers");
		for(int i=0; i<num.length; i++) {
			if(num[i]%2==0) {
				System.out.println(num[i]);
			}
		}
		
		System.out.println("Odd numbers");
		for(int i=0; i<num.length; i++) {
			if(num[i]%2!=0) {
				System.out.println(num[i]);
			}
		}

	}

}


/* With out using modulus operator(%)Gives remainder this is using division operator(/)Gives quotient
if((num[i]/2)*2==num[i]) {
	System.out.println(num[i]);
}

if((num[i]/2)*2!=num[i]) {
	System.out.println(num[i]);
}
*/