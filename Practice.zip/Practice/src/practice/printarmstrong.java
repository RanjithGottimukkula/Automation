package practice;

public class printarmstrong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r, sum=0, temp;
		int n = 153;
		temp = n;
		
		while(n>0) {
			r = n%10;
			sum = sum+(int)Math.pow(r,3);
			n = n/10;
		}
		if(temp==sum) {
			System.out.println("Armstrong");
		}else {
			System.out.println("Not Armstrong");
		}

	}
}
