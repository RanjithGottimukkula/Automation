package practice;

public class printprimenumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] num = {1,22,21,123,11,105,981,17};
		
		for(int n : num) {
			if(n>1) {
				int count = 0;
				for(int i=1; i<=n; i++) {
					if(n%i==0) {
						count++;
					}
				}
				if(count==2) {
					System.out.println(n);
				}
			}
		}
		
	}
}
