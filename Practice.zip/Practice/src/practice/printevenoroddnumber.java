package practice;

public class printevenoroddnumber {

	public static void main(String[] args) {

		int num=9;

		if(num%2==0) {
			System.out.println("Even number");
		}else {
			System.out.println("Not Even number");
		}
		
	}
}
