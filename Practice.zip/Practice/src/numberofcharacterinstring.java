
public class numberofcharacterinstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Hello My name is Joel";
		char[] ch = str.toCharArray();
		int count = 0;

		for (int i=0; i<ch.length; i++) {
		    if (ch[i]!=' ') { // Skip spaces
		        count++;
		    }
		}
		System.out.println(count);
	}
}
