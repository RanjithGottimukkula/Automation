
public class swaptwonumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10, b=20;
		System.out.println("Before swap-"+a+" " +b);
		
		//Logic 1 - using third variable
		/*int temp=a;
		a=b;
		b=temp;*/
		
		//Logic 2 - use + and - without using third variable
		a=a+b; //10+20=30
		b=a-b; //30-20=10
		a=a-b; //30-10=20
		
		System.out.println("After swap-"+a+" "+b);
	}
}
