import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TimeSheet {

public static void main(String[] args) throws InterruptedException {
String url= "https://digital.growatiopex.com/";
System.setProperty("webdriver.chrome.driver", "C:\\Users\\gottimukkula.ranjith\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
WebDriver driver= new ChromeDriver();
driver.manage().window().maximize();
driver.get(url);
WebElement email = driver.findElement(By.name("identifier"));
email.sendKeys("gottimukkula.ranjithkumar@iopex.com");
//driver.close();

WebElement next = driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/div/button/span"));
next.click();
Thread.sleep(10000);

WebElement pass = driver.findElement(By.xpath("//*[@id=\"password\"]/div[1]/div/div[1]/input"));
pass.sendKeys("P@$$word@6272");

WebElement next1 = driver.findElement(By.xpath("//*[@id=\"passwordNext\"]/div/button/span"));
next1.click();
Thread.sleep(7000);

WebElement next2 = driver.findElement(By.xpath("//*[@id=\"custom-menu-icon-toggle\"]"));
next2.click();
Thread.sleep(5000);

WebElement next3 = driver.findElement(By.xpath("//*[@id=\"pslip\"]/img"));
next3.click();
Thread.sleep(5000);


}

}
