
public class MethodsDemo2 {
	
	public String getUserData() {
		System.out.println("hello world");
		return "RanjithKumar";
	}
}
//3-27thlecture 