package stepImplementations;

import java.io.File;

import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class StepDefination {
	static WebDriver driver = null;
	static String sen = "";
	static ExtentTest test;
	static ExtentReports report;
	
	//report
	@BeforeClass
	public static void startTest()  {
		report = new ExtentReports(System.getProperty("C:\\Users\\gottimukkula.ranjith\\Documents\\Maven Project\\SeleniumTesting\\test-output")+"ReportResults.html");
		test = report.startTest("ExtentDemo");
		}
	
	boolean theDir = new File("C:\\Users\\gottimukkula.ranjith\\Documents\\Maven Project\\SeleniumTesting\\src\\main\\java\\Works").mkdir();
	
	//screenshot
	public static void screenShot() throws IOException, InterruptedException {
		String path = "C:\\Users\\gottimukkula.ranjith\\Documents\\Maven Project\\SeleniumTesting\\src\\main\\java\\Works\\"+sen+".png";
		File s = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(s, new File(path));
		}
	
	@Test
	@Given("User is on login page")
	public void user_is_on_login_page() throws InterruptedException, IOException {
		sen = "User is on login page";
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\gottimukkula.ranjith\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		String url = "https://olasandbox.service-now.com/ola/?id=landing";
		driver.get(url);
		Thread.sleep(3000);
		//driver.switchTo().frame("gsft_main"); 
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("admin_npi");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("AdminIopex@12345");
		//Thread.sleep(3000);
		screenShot();
		Thread.sleep(3000);
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        
        test.log(LogStatus.PASS, "Navigated ");
        if(driver.getTitle().equals("Service Portal - Offer Lifecycle Operations")) {
    		test.log(LogStatus.PASS, "Navigated to the specified URL");
    		}
    	else {
    		test.log(LogStatus.FAIL, "Test Failed");
    		}
        }
	
	@When("user click on the tokyo")
	public void user_click_on_the_tokyo() throws IOException, InterruptedException {
		sen = "user click on the tokyo";
        WebElement ele = driver.findElement(By.xpath("//*[text()='Tokyo']"));
        ele.click();
        }
	
	@And("click on the workstream summary")
	public void click_on_the_workstream_summary() {
		sen = "user click on the AppEngine";
		driver.findElement(By.xpath("//*[@id=\"ProductTabContent\"]/div/div[1]/div")).click();
		}
	
	@Then("user see the workstreams")
	public void user_see_the_workstreams() {
		}
	
	@AfterClass
	public static void endTest() {
		report.endTest(test);
		report.flush();
		}
}