package stepImplementations;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

public class JUnitHTMLReporter {
	
	public static void main(String[] args) {
		  LinkedList <String> l1 = new LinkedList <String> ();
		          l1.add("Red");
		          l1.add("Yellow");
		          l1.add("Green");
		          l1.add("Risk");
		          System.out.println("List of first linked list: " + l1);
		          
		 LinkedList <String> l2 = new LinkedList <String> ();
		          l2.add("Dependency");
		          l2.add("Product");
		          l2.add("Workstream");
		          l2.add("Status");
		          System.out.println("List of second linked list: " + l2);
		        
		        LinkedList <String> a = new LinkedList <String> ();
		        a.addAll(l1);
		        a.addAll(l2);
		        System.out.println("New linked list: " + a);
		        
		        
		        LinkedList <String> b = new LinkedList <String> ();
		        b.remove(a);
		        System.out.println("New linked list: " + b);
		        
		             }

	static File junitReport;
	static BufferedWriter junitWriter;

	@BeforeClass
	public static void setUp() throws IOException {

		String junitReportFile = System.getProperty("user.dir")+ "\\junitReportFile.html";
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
		Date date = new Date();
		junitReport = new File(junitReportFile);
		junitWriter = new BufferedWriter(new FileWriter(junitReport, false));
		junitWriter.write("<html><b><center>RANJITH KUMAR</center></b><body>");
		junitWriter.write("<h1>Test Execution Summary - " + dateFormat.format(date)+ "</h1>");
	}

	@AfterClass
	public static void tearDown() throws IOException {

		junitWriter.write("</body>AUTOMATION</html>");
		junitWriter.close();
		Desktop.getDesktop().browse(junitReport.toURI());

	}

	@Rule
	public TestRule watchman = new TestWatcher() {

		@Override
		public Statement apply(Statement base, Description description) {
			return super.apply(base, description);
		}

		@Override
		protected void succeeded(Description description) {
			try {
				junitWriter.write(description.getDisplayName() +" "+"success!");
				junitWriter.write("<br/>");
			} catch (Exception e1) {
				System.out.println(e1.getMessage());
			}
		}

		@Override
		protected void failed(Throwable e, Description description) {
			try {
				junitWriter.write(description.getDisplayName() +" "+ "Failed!");
				junitWriter.write("<br/>");
			} catch (Exception e2) {
				System.out.println(e2.getMessage());
			}
		}
	};
}
